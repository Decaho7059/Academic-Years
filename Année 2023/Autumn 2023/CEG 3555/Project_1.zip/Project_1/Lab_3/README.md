# Lab3CEG3155

This repository holds the vhdl implementation for a functionning traffic light.
Our traffic lights has two main functions. 
  Providing traffic light for a Main street
  Providing traffic light for a side street.
  
 The requirements of this laboratory is described in the guidelines file. 
 Our implementation is realized using structural vhdl.

/*Ex1 devoir4 CSI2772A*/

/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Ce programme retourne le nombre total d'heures de cours suivi
* par un etudiant ainsi que la note moyenne de ce �tudiant
*/

#include <iostream>
#include "myFile1a.h"
#include "myFile1b.h"


// Constructeur de course
Course::Course(int num, int hours) {
    this->num = num;
    this->hours = hours;
}

int Course::getNum() {
    return this->num;   //retourne le num�ro de cours
}

int Course::getHours() {
    return this->hours;   //retoune le nombre d'heures du cours
}

// Constructeur de Student
Student::Student(int numID, int maxCourses) {
    this->numID = numID;
    this->maxCourses = maxCourses;
    this->nbCourses = 0;
    this->List_grades = new int[maxCourses];
    this->List_courses = new Course * [maxCourses];
}

//Destructeur de Student
Student::~Student() {
    delete[] List_grades;
    for (int i = 0; i < nbCourses; i++) {
        delete List_courses[i];
    }
    delete[] List_courses;
}

//Calculer la moyenne des notes
double Student::average() {
    double average = 0;
    for (int i = 0; i < this->nbCourses; i++) {
        average += this->List_grades[i];
    }
    if (this->nbCourses > 0) {
        average /= this->nbCourses;
    }

    return average;
}

//Calculer le nombre total d'heures
int Student::totalHours() {
    Course* course;
    int totalHours = 0;
    for (int i = 0; i < this->nbCourses; i++) {
        course = this->List_courses[i];
        totalHours += course->getHours();
    }
    return totalHours;
}

//Ajouter un cours avec une note
bool Student::addCourse(Course* course, int notes) {
    if (this->nbCourses >= this->maxCourses) {
        return false; // Nombre maximum de cours d�pass�
    }
    else {
        this->List_grades[nbCourses] = notes;  //Ajout de la note au tableau
        this->List_courses[nbCourses] = new Course(course->getNum(), course->getHours()); //Creer un nouveau cours 
        nbCourses++;
    }

    return true;
}




int main() {
    Course Math(100, 60);
    Course ITI(200, 120);
    Student Yan(1, 35);
    Student Jane(2, 35);
    Yan.addCourse(&Math, 15);
    Yan.addCourse(&ITI, 12);
    Jane.addCourse(&Math, 11);
    Jane.addCourse(&ITI, 16);

    std::cout << "The total hours of Yan is " << Yan.totalHours() << std::endl;
    std::cout << "The average of Yan is " << Yan.average() << std::endl;
    std::cout << "The total hours of Jane is " << Jane.totalHours() << std::endl;
    std::cout << "The average of Jane is " << Jane.average() << std::endl;

    std::cout << "Enter a number to exit..." << std::endl;
    int exitCode;
    std::cin >> exitCode;

    return 0;
}

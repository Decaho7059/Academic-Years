/*Ex2 devoir4 CSI2772A*/

/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Ce programme retourne un tableau contenant un ensemble 
* d'entier entrer par l'utilisateur. et retourne une erreur
* si la taille du tableau entrer n'est pas coorecte
*/

#include <iostream> 
#include "myFile2.h"
#include <algorithm>

using namespace std;

// Constructeur pour initialiser un tableau d'ensemble
SetInt::SetInt(int tab[], int size) {
    elem = new int[size];
    std::copy(tab, tab + size, elem);
    this->size = size;
}

// Destructeur pour lib�rer la m�moire
SetInt::~SetInt() {
    delete[] elem;
}

// Constructeur de copie
SetInt::SetInt(const SetInt& other) {
    elem = new int[other.size];
    std::copy(other.elem, other.elem + other.size, elem);
    size = other.size;
}

// Ajouter un �l�ment � l'ensemble
void SetInt::add(int value) {
    if (!contains(value)) {
        int* newElem = new int[size + 1];
        std::copy(elem, elem + size, newElem);
        newElem[size] = value;
        delete[] elem;
        elem = newElem;
        size++;
    }
}

// Supprimer un �l�ment de l'ensemble
void SetInt::remove(int value) {
    if (size == 0) {
        std::cout << "Il n'y a aucun �l�ment � supprimer. L'ensemble est vide." << std::endl;
        return;
    }

    int index = -1;
    for (int i = 0; i < size; i++) {
        if (elem[i] == value) {
            index = i;
            break;
        }
    }

    if (index != -1) {
        for (int i = index; i < size - 1; i++) {
            elem[i] = elem[i + 1];
        }
        size--;
    }
    else {
        std::cout << "L'�l�ment " << value << " n'a pas �t� trouv� dans l'ensemble." << std::endl;
    }
}

// Nombre d'�l�ments dans l'ensemble
int SetInt::nbElem() {
    return size;
}

// Obtenir un tableau d'�l�ments
int* SetInt::tabElem() {
    if (size == 0) return nullptr;
    int* tab = new int[size];
    std::copy(elem, elem + size, tab);
    return tab;
}

// V�rifier si un �l�ment est pr�sent dans l'ensemble
bool SetInt::contains(int value) {
    return std::find(elem, elem + size, value) != elem + size;
}

int main() {
    SetInt a; 	// object creation
    int* tab;

    while (a.nbElem() < 5)
    {
        cout << "add an int element" << endl;
        int elem;
        cin >> elem;
        a.add(elem);

    }
    cout << "a contains 10 :" << a.contains(10) << endl;
    cout << "remove 10 " << endl;
    a.remove(10);
    cout << "a contains 10 :" << a.contains(10) << endl;
    cout << "a contains :" << a.nbElem() << " elements " << endl;
    tab = a.tabElem();
    cout << "Les elements de a sont :" << endl;
    for (int i = 0; i < a.nbElem(); i++)
        cout << tab[i] << endl;

    return 0;
}
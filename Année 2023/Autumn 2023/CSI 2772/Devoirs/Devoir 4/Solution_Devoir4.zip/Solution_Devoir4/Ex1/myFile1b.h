/*myFile1b.h, Ex1 devoir4 CSI2772A*/


#include <iostream>
using namespace std;

class Student {
	int numID;
	int nbCourses;
	int maxCourses;
	int* List_grades;
	Course** List_courses;
public:
	Student(int, int); 	//constructor
	~Student(); 		//destructor
	double average();
	int totalHours();
	bool addCourse(Course*, int);
};

/*********DEFINITION DE LA CLASSE Student********************/

/******************Constructor*******************/
Student::Student(int number, int max) : numID(number), nbCourses(0), maxCourses(max) {
	List_grades = new int[maxCourses];
	List_courses = new Course * [maxCourses];
}


/******************Destructor********************/
Student::~Student() {
	delete[] List_grades;
	delete[] List_courses; // do not delete the course pointers, since 
	//they are not created here! 
}

/******************average()******************/
double Student::average() {
	double total = 0;
	for (int i = 0; i < nbCourses; i++)
		total += List_grades[i];
	return total / nbCourses;
}


/******************addCourse()method*************/
bool Student::addCourse(Course* nov, int grade) {
	if (nbCourses >= maxCourses)
		return false;
	List_courses[nbCourses] = nov;
	List_grades[nbCourses] = grade;
	nbCourses++;
	return true;
}

/******************totalHours()method*************/
int Student::totalHours() {
	int i, tot = 0;
	for (i = 0;i < nbCourses;i++)
		tot += List_courses[i]->getHours();
	return tot;
}

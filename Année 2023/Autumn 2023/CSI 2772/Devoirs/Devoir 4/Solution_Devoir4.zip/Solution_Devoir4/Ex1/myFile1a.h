/*myFile1a, Ex1 devoir4 CSI2772A*/

#include <iostream>
using namespace std;
class Course {
    int num;
    int hours;
public:
    Course(int, int); 	//constructor
    int getNum();
    int getHours();
};


/*********DEFINITION DE LA CLASSE Course********************/

/*******************Constructor*****************/
Course::Course(int n, int h) : num(n), hours(h)
{}

/************************ getNum()method*********/
int Course::getNum() {
    return num;
}

/************************* getHours()method ******/
int Course::getHours() {
    return hours;
}


/*Ex2 devoir4 CSI2772A*/

#include <cstdlib> 
using namespace std;
class SetInt
{
public:
	SetInt() : elem(NULL), size(0) {};
	SetInt(int[], int);
	~SetInt();
	SetInt(const SetInt&);  // copy constructor
	void add(int);
	void remove(int);
	bool contains(int);
	int nbElem();
	int* tabElem();
private:
	int* elem;
	int size;
	bool containsIn(int n, int&);
};


/*Class definition*/
/*File myFile2.cpp*/

SetInt::SetInt(int t[], int n) 		//Constructor
{
	size = 0;
	elem = NULL;
	for (int i = 0; i < n; i++) add(t[i]);
}

SetInt::~SetInt() 			//Destructor
{
	delete[] elem;
}



SetInt::SetInt(const SetInt& e) 	//Copy constructor
{
	size = e.size;
	if (size == 0) elem = NULL;
	else {
		elem = new int[size];
		for (int i = 0; i < size; i++)
			elem[i] = e.elem[i];
	}
}



void SetInt::add(int n) {
	if (size == 0) {
		size = 1;
		elem = new int;
		*elem = n;
	}
	else
		if (!contains(n)) {
			int* novElem = new int[size + 1];
			for (int i = 0; i < size; i++)
				novElem[i] = elem[i];
			novElem[size] = n;
			size++;
			delete[] elem;
			elem = novElem;
		}
}


void SetInt::remove(int n)
{
	int pos;
	if (containsIn(n, pos)) {
		if (size == 1) {
			size = 0;
			delete[] elem;
			elem = NULL;
		}
		else {
			int* novElem = new int[size - 1];
			for (int i = 0, j = 0; i < pos; i++)
				novElem[i] = elem[i];
			for (int i = pos + 1; i < size; i++)
				novElem[i - 1] = elem[i];
			size--;
			delete[] elem;
			elem = novElem;
		}
	}
}


bool SetInt::contains(int n) {
	int pos;
	return containsIn(n, pos);
}

int SetInt::nbElem() {
	return size;
}

int* SetInt::tabElem() {
	if (size == 0) return NULL;
	int* res = new int[size];
	for (int i = 0; i < size; i++) res[i] = elem[i];
	return res;
}


/*Returns true if n belongs to the set, false otherwise.
Pos indicates the position of n if it is in the set, otherwise the position where it should be added*/

bool SetInt::containsIn(int n, int& pos) {
	for (pos = 0; pos < size && elem[pos] != n; pos++);
	return (pos < size);
}





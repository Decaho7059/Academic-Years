/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Ce programme permet de construire un jeu de 32 cartes
* ce jeu de carte sera repr�senter dans un tableau d'�l�ment distincts.
*/

#include <iostream>
using namespace std;

enum Color { club, diamond, spades, heart };
enum Face { seven, eight, nine, ten, jack, queen, king, ace };

struct Card {
	Color color;
	Face face;
};

int main() {
    struct Card game[32];
    int i = 0;

    for (int color = club; color <= heart; color++) {
        for (int face = seven; face <= ace; face++) {

            // initialiser les cartes tout en incr�mentant l'index
            game[i].color = (enum Color)color;
            game[i].face = (enum Face)face;
            i++;
        }
    }
}


// if the original main has some problem in your compiler,
// please use this main function :)
int main_mac() {
    Card game[32];
    int i = 0;
    const Color colorVector[] = { club, diamond, spades, heart };
    const Face faceVector[] = { seven, eight, nine, ten, jack, queen, king, ace };

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 8; j++) {
            game[i * j].color = colorVector[i];
            game[i * j].face = faceVector[j];
        }
    }

    return 0;
}
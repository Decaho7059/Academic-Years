/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Devoir 3 
* 
* ce programme grace � la fonction testPair() 
* permet de determiner si un joueur de poker a 
* une paire de carte dans sa main
*/

#include <iostream>
using namespace std;

enum Color { club, diamond, spades, heart };
enum Face { seven, eight, nine, ten, jack, queen, king, ace };

struct Card {
    Color color;
    Face face;
};

typedef Card Hand[5];


/* testPair() function*/

bool testPair(const Hand& h) {
    int cptFace[8] = { 0 };  // tableau de stockage du compte

    for (int i = 0; i < 5; i++) {
        cptFace[h[i].face]++;  // incrementer le cpt dans le tableau
    }

    for (int i = 0; i < 8; i++) {
        if (cptFace[i] >= 2) {  // verifie si des cartes sont 2 ou plus
            return true;
        }
    }
    return false;
}

/*Example of main()*/
int main() {
    bool testPair(const Hand&);
    Hand myHand = { {club, nine},
                   {diamond, eight},
                   {spades, ace},
                   {spades, jack},
                   {club, ace} };
    cout << "\nI have at least: " << testPair(myHand) << "pair" << endl;
    return 0;
}
/*Ex2 - Devoir 3 CSI2772A*/

/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Devoir 3 - Exo 2
*
* ce programme permet d'initialiser une liste simplement chain�e
* (structures de donn�s chain�es) avec les donn�es (student et grade)
*/

#include "myLinkedList.h"

int main()
{
	Evaluation* first = NULL;	//Pointer on the first element of the list
	//the list is empty, so initialization to NULL
	int number = 0;			//number of elements in the linked  list 
	int choice;			//choice for the menu

	do
	{
		cout << endl << endl << "1) Display  of the complete linked list.\n";
		cout << "2) Insert an element\n";
		cout << "3) Remove an element.\n";
		cout << "4) Calculation of the class average.\n";
		cout << "5) Exit the program.\n" << endl << endl;
		cout << "Your choice ??:";
		cin >> choice;

		switch (choice)
		{
		case 1: display(first);
			break;
		case 2: first = add(first, number);
			break;
		case 3: first = remove(first, number);
			break;
		case 4: average(first, number);
			break;
		case 5: exit(0);
		default:
			break;
		}
	} while (1);
	return 0;
}



/*
*add() Function*
**/
Evaluation* add(Evaluation* p, int& number) {
    int insert_index, grade;
    char name[capacity]; // name permet de stocker le nom des etudiants

    // Demander � l'utilisateur de fournir une position valide pour l'insertion
    do {
        cout << "After which element you want to insert ? (0 for start): ";
        cin >> insert_index;
    } while (insert_index > number || insert_index < 0); // V�rification de la validit�

    cout << "\n\tEntering the item from the chained list.\n" << endl;
    cout << "Enter the student: ";
    cin.ignore(256, '\n');
    cin.getline(name, capacity);
    cout << "Enter the grade: ";
    cin >> grade;

    // Cr�er un pointeur pointant vers une structure 
    // Evaluation et allocation de l'espace m�moire n�cessaire
    Evaluation* proEva =
        (Evaluation*)malloc(sizeof(Evaluation));

    // Initialiser le nom de l'�tudiant
    for (int i = 0; i < capacity; i++) {
        proEva->student[i] = name[i];
    }

    // Initialiser la note de l'�tudiant
    proEva->grade = grade;

    // Si l'insertion est en d�but de liste remplacer p
    if (insert_index == 0) {
        if (number != 0) { // S'il n'est pas le seul �l�ment
                proEva->next = p;  // Lier la t�te p
            }
            p = proEva; // devient la t�te
    }
    else { // insertion apr�s un certain �l�ment
        Evaluation* preEval = p; // Trouver le n�ud pr�c�dent
        for (int i = 1; i < insert_index; i++) {
            preEval = preEval->next;
        }

        // Lier le nouveau n�ud � la liste
        proEva->next = preEval->next;
        preEval->next = proEva;
    }

    // augmenter le nombre de n�uds dans la liste de 1
    number++;

    // retourner la t�te p
    return p;
}


/**
 *remove() Function*
 **/

Evaluation* remove(Evaluation* p, int& number) {
    //ne pas supprimer s'il n'y a pas un seul n�ud
    if (number == 0) {
        cout << endl << "There are no elements in the list!" << endl;
        return p;
    }

    int remove_index;

    // Laissez l'utilisateur fournir une position valide pour la suppression
    do {
        cout << "What is the number of the element to delete ?: ";
        cin >> remove_index;
    } while (remove_index > number || remove_index < 1); // V�rification de la validit�

    // Si on supprime le premier n�ud
    if (remove_index == 1) {
        if (number == 1) { // Si la t�te est le seul n�ud
            p = NULL;
        }
        else {       // S'il y a un n�ud apr�s la t�te
            p = p->next; // Laissez le n�ud suivant �tre la t�te
        }
    }
    else {   // Condition g�n�rale : supprimer un n�ud qui n'est pas la t�te
        Evaluation* preEva = p; // Trouver le n�ud pr�c�dant le n�ud � supprimer
        for (int i = 2; i < remove_index; i++) {
            preEva = preEva->next;
        }

        // Supprimer le n�ud en r�affectant preEva->next au n�ud suivant
        Evaluation* temp = preEva->next;
        preEva->next = preEva->next->next;
        free(temp);
    }

    number--;
    return p;
}

/**
 *display() Function *
 **/
void display(Evaluation* p) {
    Evaluation* c = p;  // Copie du pointeur vers c
    while (c != NULL) { // Afficher si c existe
        cout << endl << "Student: " << c->student << endl;
        cout << "The grade is: " << c->grade << endl;
        c = c->next; // Passer au n�ud suivant
    }
}

/**
 *average() Function *
 **/
int average(Evaluation* p, int const& nbre) {
    Evaluation* c = p; // Copie du pointeur vers c 
    int sum = 0, avg;  // Initialiser la somme � 0

    while (c != NULL) { // Calculer si c existe
        sum += c->grade;
        c = c->next; // Passer au n�ud suivant
    }
    if (nbre > 0) {
        avg = sum / nbre; // Calculer la moyenne des notes
        cout << "The average of the class is: " << avg << endl;
    }
    else {
        cout << "There is no item in the list ! " << endl;
    }

    return avg;
}






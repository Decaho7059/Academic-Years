/*Ex2 - Devoir 3 CSI2772A*/

#include "myLinkedList.h"


int main()
{
	Evaluation* first = NULL;	//Pointer on the first element of the list
						//the list is empty, so initialization to NULL
	int number = 0;			//number of elements in the linked  list 
	int choice;			//choice for the menu

	do
	{
		cout << endl << endl << "1) Display  of the complete linked list.\n";
		cout << "2) Insert an element\n";
		cout << "3) Remove an element.\n";
		cout << "4) Calculation of the class average.\n";
		cout << "5) Exit the program.\n" << endl << endl;
		cout << "Your choice ?:";
		cin >> choice;

		switch (choice)
		{
		case 1: display(first);
			break;
		case 2: first = add(first, number);
			break;
		case 3: first = remove(first, number);
			break;
		case 4: average(first, number);
			break;
		case 5: exit(0);
		default:
			break;
		}
	} while (1);
	return 0;
}

/******************************add() Function****************************** */
Evaluation* add(Evaluation* p, int& number)
{
	Evaluation* para, * para2, * para3;      //pointers for insertion
	int num;		//places or inserts the new element
	cout << "After which element you want to insert ? (0 for start): ";
	cin >> num;
	if ((num < 0) || (num > number)) 	//check if the place is valid
	{
		cout << "\n\nImpossible !!\n";
		return(p);		//the past element remains the first
	}
	para = new Evaluation;		//we reserve memory for the structure

	if (para == NULL)	// check if this allocation went well 
	{
		cout << "Insufficient memory";
		exit(2);
	}
	if (num == 0)		//the new element to be inserted is the first in the list
	{
		para2 = p;
		p = para;
		para->next = para2;
	}
	else if (num == number)	// the new element to be inserted is the last of the list 
	{
		para2 = p;
		for (int i = 0;i < num - 1;i++) para2 = para2->next;
		para2->next = para;
		para->next = NULL;
	}

	else		// the new element to be inserted is between the first and the last one
	{
		para2 = p;
		for (int i = 0;i < num - 1;i++) para2 = para2->next;
		para3 = para2->next;
		para2->next = para;
		para->next = para3;
	}
	cout << "\n\tEntering the item from the chained list.\n\n";
	cout << "Enter the student: ";
	cin.ignore(INT_MAX, '\n');
	cin.getline(para->student, capacity);
	cout << "\nEnter the grade: ";
	cin >> para->grade;
	number++;	//increments the number of elements 
	return(p);	//returns a pointer on the first element
}

/**************remove() Function ***********************************************/

Evaluation* remove(Evaluation* p, int& number)
{
	Evaluation* para2, * para3, * para4;
	int num;	//place of the element to be deleted
	cout << "what is the number of the element to delete ?: ";
	cin >> num;
	if ((num > number) || (num <= 0)) 	//check if the element exists
	{
		cout << "Impossible !!";
		return(p);	// return of the pointer as in this case
	}
	if (num == 1)		//the element to be deleted is the first one
	{
		if (number == 0)	// the element to be deleted is the only existing element
		{
			delete p;	//memory release
			p = NULL;	//there is no more element
		}
		else
		{
			para2 = p->next;	//there are several elements
			delete p;
			p = para2;
		}
	}

	else if (num == number)	// the element to be deleted is the last one 
	{
		para2 = p;
		for (int i = 1;i < num - 1;i++) para2 = para2->next;
		para3 = para2->next;
		delete para3;
		para2->next = NULL;
	}

	else	//the element to be deleted is between the first and the last one 
	{
		para2 = p;
		for (int i = 1;i < num - 1;i++) para2 = para2->next;
		para3 = para2->next;
		para4 = para3->next;
		delete para3;
		para2->next = para4;
	}
	number--;	//decrements the number of elements
	return(p);	//returns the pointer on the first element
}






/************************ display() Function *************************/
void display(Evaluation* p)
{
	Evaluation* para;
	para = p;
	if (para == NULL)
	{
		cout << "there is no element..." << endl;
	}
	while (para != NULL){
		cout << "\nStudent :" << para->student;
		cout << "\nThe grade is :" << para->grade << endl;
		para = para->next;
	};
}






/************** **********average() Function ************************/
int average(Evaluation* p, int const& nbre)
{
	Evaluation* para;
	int ave = 0;
	para = p;
	if (para == NULL)
	{
		cout << "\nThere is no element...\n";
		cout << "\nWe cannot calculate an average !!\n";
		return(0);
	}
	do
	{
		ave += (para->grade);
		para = para->next;
	} while (para != NULL);
	cout << "\nThe average of the class is: " << ave / nbre;
	return(1);
}







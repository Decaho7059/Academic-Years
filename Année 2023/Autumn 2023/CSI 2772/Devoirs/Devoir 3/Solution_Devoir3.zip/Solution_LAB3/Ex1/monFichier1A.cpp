/*Ex1a - Devoir 3 CSI2772A*/

#include <iostream>
using namespace std;

enum Color { club, diamond, spades, heart };
enum Face { seven, eight, nine, ten, jack, queen, king, ace };

struct Card
{
	Color color;
	Face face;
};

int main()
{
	Card game[32];
	int i, j, x = 0;
	for (i = 0; i < 8; i++)
		for (j = 0; j < 4; j++)
		{
			game[x].face = (Face)i;
			game[x].color = (Color)j;
			x++;
		}
	return 0;
}

/*MonFichier3.cpp : Ex3 Devoir2 CSI2772A*/

#include <iostream>
using namespace std;

int** triangleInf(int n)
{
	int** res = new int* [n + 1];
	for (int i = 0; i <= n; i++)
	{
		res[i] = new int[i + 1];
		res[i][0] = 1;
		res[i][i] = 1;
		for (int j = 1; j < i; j++)
			res[i][j] = res[i - 1][j - 1] + res[i - 1][j];
	}
	return res;
}

int main() {
	int** tab;
	const int size = 10;
	tab = triangleInf(size);
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j <= i; j++)
			cout << tab[i][j] << " ";
		cout << endl;
	}
}
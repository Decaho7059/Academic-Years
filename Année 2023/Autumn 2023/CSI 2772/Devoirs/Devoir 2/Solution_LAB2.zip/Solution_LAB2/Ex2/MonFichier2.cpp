/*MonFichier2.cpp : Ex2 Devoir2 CSI2772A*/

#include "MonFichier2.h"

int main() {
	int monTab[size_tab] = { 2,4,88,20,3,55,87,134,2,5 };

	cout << "Affichage du tableau non trie :" << endl;
	for (int i = 0;i < size_tab;i++) {
		cout << monTab[i] << endl;
	}
	trier(monTab, size_tab);
	cout << "Affichage du tableau trie :" << endl;
	for (int i = 0;i < size_tab;i++) {
		cout << monTab[i] << endl;
	}
}

void trier(int tab[], int size)
{
	int cle;

	for (int j = 1;j < size;j++)	//du 2eme element au dernier
	{
		cle = tab[j];		//On  sauvegarde  l'element cle 
		int i = j - 1;
		while ((i >= 0) && (tab[i] > cle)) /*On regarde a partir de l'element precedent jusqu'au premierelement du tableau (i--) jusqu'a ce que l'element cle soit plus petit que l'element courant*/
		{
			tab[i + 1] = tab[i];	//on decale les elements si ce n'est pas le cas
			i--;
		}
		tab[i + 1] = cle;		//inserer l'element  cle
	}
}

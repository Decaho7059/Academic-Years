/*monfichier1.cpp : Ex1 Devoir2 CSI2772A*/

#include <iostream>
using namespace std;
int main(void) {
	int tab[10];			//declaration d'un tableau de 80 entiers
	int* p;				//declaration d'un pointeur sur entier
	for (int i = 0;i < 10;i++)
	{
		tab[i] = i * i;			//initialisation des elements du tableau
	}
	cout << tab[2] << endl;	//affiche 4
	tab[2] = tab[1];			//affectation du 3eme element avec la valeur du 2eme element 
	cout << tab[2] << endl;	//affiche 1
	tab[2] = *(tab + 1);		//affectation du 3eme element avec la valeur du 2eme element
	cout << tab[2] << endl;	//affiche 1
	*(tab + 2) = tab[1];		// la meme affectation
	cout << tab[2] << endl;	//affiche 1
	*(tab + 2) = *(tab + 1);		// la meme affectation
	cout << tab[2] << endl;	//affiche 1
	p = &tab[0];	// ou p=tab;	//on affecte l'adresse du 1er element du tableau au pointeur p
	p = tab + 1;			//on affecte l'adresse du 2eme element au meme pointeur p
	tab[4] = *p;			//affectation du 5eme element avec la valeur du 2eme element
	cout << tab[4] << endl;	//affiche 1
}


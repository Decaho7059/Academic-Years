/*MonFichier2.cpp : Ex2 Devoir2 CSI2772A*/

/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Ce programme effectue un tri par insertion d'un tableau de 10 entiers
* ce tri est r�aliser en traitant 2 param�tre : le nom du tableau et 
* le nombre de ses �l�ments
*/

#include "monfichier2.h"

int main() {
	int monTab[size_tab] = { 2,4,8,20,3,55,87,13,2,5 };

	cout << "Affichage du tableau non trie :" << endl;
	for (int i = 0; i < size_tab; i++) {
		cout << monTab[i] << endl;
	}
	trier(monTab, size_tab);
	cout << "\nAffichage du tableau trie :" << endl;
	for (int i = 0; i < size_tab; i++) {
		cout << monTab[i] << endl;
	}
}

void trier(int tab[], int size)
{
	int val;

	for (int i = 1; i < size; i++)
	{
		int a;
		val = tab[i]; //valeur de comparaison

		for (a = i - 1; a >= 0; a--) //trie par insertion
		{
			if (tab[a] > val)
			{
				tab[a + 1] = tab[a];  //deplacer les elements sup�rieur � la position de reference
			}
			else {
				break;
			}
		}
		tab[a + 1] = val;
	}

}

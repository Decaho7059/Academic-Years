/* Exercice 1 du devoir 2 du cours CSI 2772A */

/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Ce programme retourne des resultat les un apr�s 
* les autres suivant un mod�le impos�
*/

#include <iostream>

using namespace std;

int main(void) {
	int tab[10];
	int* p;
	int d;

	for (int i = 0; i < 10; i++) {
		tab[i] = i * i;
	}
	cout << tab[2] << "\n";
	tab[2] = tab[1];
	cout << tab[2] << "\n";
	tab[2] = *(tab + 1);
	cout << tab[2] << "\n";
	*(tab + 2) = tab[1];
	cout << tab[2] << "\n";
	*(tab + 2) = *(tab + 1);
	cout << tab[2] << "\n";
	p = &tab[0];
	p = tab + 1;

	tab[4] = *p;
	cout << tab[2] << "\n";

}
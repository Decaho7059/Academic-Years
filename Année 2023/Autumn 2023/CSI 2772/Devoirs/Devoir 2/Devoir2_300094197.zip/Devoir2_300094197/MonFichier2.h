/*MonFichier2.h : Ex2 Devoir2 CSI2772A*/

/*MonFichier2.cpp : Ex2 Devoir2 CSI2772A*/

/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Ebauche du programme de la question 2 du devoir
*/


#include <iostream>
using namespace std;
const int size_tab = 10;	//nombre d'elements du tableau

void trier(int tab[], int size);
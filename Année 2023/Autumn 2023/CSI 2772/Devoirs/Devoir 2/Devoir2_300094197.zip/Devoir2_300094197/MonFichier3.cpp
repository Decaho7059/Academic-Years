/*MonFichier3.cpp : Ex3 Devoir2 CSI2772A*/

/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
* 
* Ce programme retourne une matrice triangulaire inf�rieure
* � n lignes repr�sentant un triangle de pascal.
*/

#include <iostream>
using namespace std;

int** triangleInf(int n)
{
	static int matrix[1024][1024];   //creer un tableau de k lignes et k colonnes
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (j == 0)
			{
				matrix[i][j] = 1; // s'il n'y a aucune colonnes
			}
			else {
				if(j > i)
				{
					matrix[i][j] = 0;   // si les colonnes > lignes
				}
				else
				{
					matrix[i][j] = matrix[i - 1][j - 1] + matrix[i - 1][j]; //remplir les lignes et fonction des lignes pr�c�dentes
				}
			}
		}
	}
	static int* cpt[1024];  // creer un tableau de compteur
	for (int i = 0; i < n; i++)
	{
		cpt[i] = matrix[i];  //remplir le tableau avec les valeurs des lignes de la matrices
	}
	return cpt;
}

int main() {
	int** tab;
	const int size = 10;
	tab = triangleInf(size);
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j <= i; j++)
			cout << tab[i][j] << " ";
		cout << endl;
	}
}
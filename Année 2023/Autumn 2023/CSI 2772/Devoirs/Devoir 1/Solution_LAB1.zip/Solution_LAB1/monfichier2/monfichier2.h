#include <iostream>
#include <iomanip>
#include <process.h>

using namespace std;

const double Pi = 3.14159;

char menu(void);
int volume(double const& ray, double const& haut);
int surface(double const& ray);


/*monfichier1.cpp : Ex1 Devoir1 CSI2772A*/

#include "monfichier1.h"

int main() {
	int nombre;
	float adf;
	char adc;

	cout << "Taille en octets d'un caractere: " << sizeof(char) << endl;
	cout << "Taille en octets d'un entier: " << sizeof(int) << endl;
	cout << "Taille en octets d'un reel: " << sizeof(float) << endl;
	cout << "Taille en octets d'un double: " << sizeof(double) << endl;
	cout << "Taille en octets d'un entier court: " << sizeof(short int) << endl;
	cout << "Taille en octets d'un entier non signe: " << sizeof(unsigned int) << endl << endl << endl;

	cout << "Saisissez un entier: ";
	cin >> nombre;

	// Premiere maniere d'afficher le nombre
	cout << endl;
	cout << "nombre en decimal : \t" << nombre << endl;
	cout << "nombre en octal : \t" << oct << nombre << endl;
	cout << "nombre en hexa : \t" << hex << nombre << endl << endl;

	// Deuxieme maniere d'afficher le nombre 
	cout << "nombre en decimal : \t" << setbase(10) << nombre << endl;
	cout << "nombre en octal : \t" << setbase(8) << nombre << endl;
	cout << "nombre en hexa : \t" << setbase(16) << nombre << endl << endl;

	cout << "Saisissez un reel: \t";
	cin >> adf;
	cout << setprecision(3) << setiosflags(ios::fixed) << adf << endl;
	cout << setprecision(3) << setiosflags(ios::scientific) << adf << endl << endl << endl;

	cout << "Saisissez un caractere: \t";
	cin >> adc;
	cout << adc << endl;
	cout << int(adc) << endl;
}


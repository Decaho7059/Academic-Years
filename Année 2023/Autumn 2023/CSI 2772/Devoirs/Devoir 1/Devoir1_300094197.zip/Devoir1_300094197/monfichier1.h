#include <iostream>
#include <iomanip>
#include <string>


using namespace std;

int a;
float b;
char c;
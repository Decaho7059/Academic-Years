#include <iostream>
#include <iomanip>
#include <string>


using namespace std;

int main()

{

    cout << "Taille en octets d'un caractere : " << sizeof(char) << "\n";
    cout << "Taille en octets d'un entier : " << sizeof(int) << "\n";
    cout << "Taille en octets d'un reel : " << sizeof(float) << "\n";
    cout << "Taille en octets d'un double : " << sizeof(double) << "\n";
    cout << "Taille en octets d'un entier court : " << sizeof(short int) << "\n";
    cout << "Taille en octets d'un entier non signe : " << sizeof(unsigned int) << "\n";


    int a;  //50
    float b;  //12.354
    char c;  //Hello

    cout << "\n" << "Saisissez un entier : ";
    cin >> a;

    cout << "Nombre en decimal : " << dec << a << "\n";   //50
    cout << "Nombre en octal : " << oct << a << "\n";     //62
    cout << "Nombre en hexa : " << hex << a << "\n";      //32


    cout << "\n" << "Nombre en decimal : ";
     printf("%ld",a) ;  //50
    cout << "\nNombre en octal : ";
     printf("%o", a);  //62
    cout << "\nNombre en hexa : ";
     printf("%X", a) ;    //32
    

    cout << "\n" << "\nSaisissez un reel : ";
    cin >> b;

    cout << setprecision(3) << b << "\n";  // 12.354
    cout << hexfloat << b << "\n";  //0x1.8b5p+3 


    cout << "\n" << "Saisissez un caractere : ";
    cin >> c;

    cout << c << "\n";                // Hello
    cout << static_cast<int>(c);      //48



    return 0;
}
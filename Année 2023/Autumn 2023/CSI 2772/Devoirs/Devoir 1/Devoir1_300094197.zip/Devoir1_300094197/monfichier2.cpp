#include "monfichier2.h"


/*
* Exercice 2
*
* a) La fonction main donner en annexe 2 se charge de faire l'appelle des fonctions de calcul de surface et de volume.
* Elle se charge de demander la l'utilisateur l'op�ration qu'il veut effectuer et tant qu'il choisit une reponse valide (1 ou 2)
* la fonction charge les diff�rentes fonction et fais le calcul.
*
* Si l'utilisateur choisi la reponse 3 le programme fais la somme du nombre de fois que chaque m�thode � �t� utilis�
* puis affiche le cumul pour chacune d'elle
*
* Et apr�s ferme le programme
*
* b)
*
*
*/

char menu(void)
{
    char choix;

    cout << endl;
    cout << "Que souhaitez-vous faire ?:" << endl;
    cout << "\t-Calculer la surface du disque de rayon (Tapez 1)" << endl;
    cout << "\t-Calculer le volume du cylindre de rayon et hauteur (Tapez 2)" << endl;
    cout << "\t-Quittez le programme (Tapez 3)" << endl;
    cout << "Votre choix: ";
    cin >> choix;

    return(choix);
}

int volume(double const& ray, double const& haut)
{
    double volume = Pi * haut * pow(ray, 2);

    cout << "Le volume est : " << volume << "\n";

    return 0;
}

int surface(double const& ray)
{
    double surface = Pi * pow(ray, 2);

    cout << "La surface est : " << surface << "\n";

    return 0;
}

int main(void)
{
    char choix;
    int nvolume = 0; //nombre de fois que la fonction volume a �t� lancee
    int nsurface = 0; //nombre de fois que la fonction surface a �t� lancee
    double rayon, hauteur;

    while (1)
    {
        choix = menu();
        switch (choix)
        {
        case '1': cout << endl << "Calcul de la surface :" << endl;
            cout << "Donnez le rayon: ";
            cin >> rayon;
            nsurface++;
            surface(rayon);
            break;

        case '2': cout << endl << "Calcul du volume :" << endl;
            cout << "Donnez le rayon: ";
            cin >> rayon;
            cout << "Donnez la hauteur: ";
            cin >> hauteur;
            nvolume++;
            volume(rayon, hauteur);
            break;

        case '3':cout << endl << "Sortie du programme" << endl;
            cout << "La fonction volume a ete lancee " << nvolume << " fois" << endl;
            cout << "La fonction surface a ete lancee " << nsurface << " fois" << endl;
            exit(0);

        default: break;
        }
    }
}

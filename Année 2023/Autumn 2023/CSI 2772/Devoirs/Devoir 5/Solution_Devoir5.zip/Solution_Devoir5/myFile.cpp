
#include <iostream>
using namespace std;

#include "myFile.h"
#include "Card.h"
#include "CardsSet.h"
#include "Player.h"

int main() {
	CardsSet packet;
	Player you(packet, false);
	Player me(packet, true);
	char answer[3];
	bool continuous = true;
	cout << "Hello! " << endl;
	while (continuous)
	{
		cout << "A new game? " << endl;
		cin >> answer;
		continuous = answer[0] == 'y';
		if (continuous)
		{
			packet.novSet();
			packet.shuffle();
			packet.take();
			int p1 = you.play();
			if (p1 > 21) {
				cout << "You lost! " << endl;
			}
			else if (p1 == 21) {
				cout << "You won! " << endl;
			}
			else // the computer must play
			{
				int p2 = me.play();
				if (p2 <= 21 && p2 >= p1) {
					cout << "You lost! " << endl;
				}
				else {
					cout << "You won! " << endl;
				}
			}
		}
	}
	return 0;
}


/*Question 1: Card class definition*/
void Card::write() {

    string suit_array[4] = { "Clubs", "Diamonds", "Hearts", "Spades" };
    string card_array[13] = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };

    cout << "Card: " << card_array[(this->val) - 1] << " of " << suit_array[(this->col) - 1] << endl;
}

/*Question 2: CardsSet class definition */
void CardsSet::novSet() {
    int count = 0;

    for (int i = 1; i <= 4; i++) {
        for (int j = 1; j <= 13; j++) {
            Card newCard(color(i), j);
            this->set[count] = newCard;
            count++;
        }
    }

    this->number = count;

}



void CardsSet::shuffle() {
    srand(time(0));   // in the above header files
    int i;
    for (i = 1; i < (this->number); i++)
    {
        int n1 = rand() % number;
        int n2 = rand() % number;
        Card temp = set[n1];
        set[n1] = set[n2];
        set[n2] = temp;
    }
}



/* take () method*/
Card CardsSet::take() {
    assert(number > 0);
    return set[--number];
}




/* put() method */

void CardsSet::put(Card k) {
    assert(number < 52);
    set[number++] = k;
}


/* lookIn() method */
Card CardsSet::lookIn(int no) {
    return this->set[no - 1];
}




/* Question 3: Player class definition */
/* play() method */
int Player::play() {
    bool continuous = true;
    int points;
    while (continuous)
    {
        Card k = this->packet.take();
        inHand.put(k);
        points = countPoints();
        if (computer) 	// the computer is playing 
        {
            cout << "the computer took "; k.write(); cout << endl;
            if (points >= 16) 	// the computer decides to stop when it reaches 16 points 
            {
                cout << " the computer has " << points << " points" << endl;
                continuous = false;
            }
        }
        else 	// it is the user who plays
        {
            cout << "You get "; k.write(); cout << endl;
            cout << " Your score is " << points << " points" << endl;
            if (points < 21)
            {
                char answer[3];
                cout << "Any additional Card ? ";
                cin >> answer;
                continuous = answer[0] == 'y';
            }
            else
                continuous = false;
        }
    }
    inHand.empty();
    return points;
}


/*countPoints() method*/

int Player::countPoints() {
    int i, points = 0, ace = 0; // initialize the number of points and ace to 0 
    for (i = 1; i <= inHand.numCards(); i++)
    {
        int v = inHand.lookIn(i).value();
        if (v == 1) 	// it�s an Ace 
        {
            points += 14;
            ace++;
        }
        else
            points += v;
    }
    for (int j = 1; j <= ace && points > 21; j++)
        points -= 13; 	// if we exceed 21, we count the ace for 1 
    return points;
}

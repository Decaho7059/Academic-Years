/*Nom d'�tudiant : Gbegbe Decaho
* Num�ro d'�tudiant : 300094197
* Code du cours : CSI 2772A
*
* Ce programme permet � l'utilisateur de jouer 
* au jeu de cartes 21 avec l'ordinateur
* 
* L'utilisateur gagne s'il a dans sa main un total de carte < 21
* Mais perd s'il en a plus de m�me pour la machine contre qui
* l'utilisateur joue
*/

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <random>
#include <string>
using namespace std;

#include "myFile.h"
#include "Card.h"
#include "CardsSet.h"
#include "Player.h"

void Card::write() {
	string cardColor;
	string cardValue;

	switch (this->col) {
	case club:
		cardColor = "Clubs";
		break;
	case diamond:
		cardColor = "Diamonds";
		break;
	case heart:
		cardColor = "Hearts";
		break;
	case spade:
		cardColor = "Spades";
		break;
	default:
		cardColor = "???";
		cout << "Couleurs de carte incorrecte! Veuillez reessayer avec une couleur correcte. color : " << cardColor << endl;
		break;
	}

	switch (this->val) {
	case 1:
		cardValue = "Ace";
		break;
	case 11:
		cardValue = "Jack";
		break;
	case 12:
		cardValue = "Queen";
		break;
	case 13:
		cardValue = "King";
		break;
	default:
		cardValue = std::to_string(this->val);
		break;
	}

	cout << cardValue << " of " << cardColor << endl;
}



void CardsSet::novSet() {
	int index = 0;
	num = 0;
	for (int i = club; i <= spade; i = (color)(i + 1)) {
		for (int j = 1; j <= 13; j++) {
			set[index++] = Card((color)i, j);
			num++; // le nombre d'�l�ments dans l'ensemble
		}
	}
}

//
void CardsSet::shuffle() {
	int index;
	int shuffleL = 52; // nombre de m�langes restants dans la boucle
	int tailleTab = 52;       // taille du tableau � m�langer
	Card carteEnMain;

	// melanger les cartes
	while (shuffleL-- > 0) {
		index = rand() % tailleTab;    // la position � �changer
		carteEnMain = this->set[index]; // obtenir la carte
		this->set[index] = set[shuffleL - 1]; // obtenir la carte � �changer dans le tableau
		set[shuffleL - 1] = carteEnMain; // �changer l'�l�ment � shuffleL-1 avec celui � l'index
	}

}

//
Card CardsSet::take() {
	Card result;
	//
	if (num > 0) {
		result = this->set[--num];
		cout << "You get Card : ";
		result.write();
		cout << endl;
	}
	srand(time(0));
	return result;
}

//
Card CardsSet::lookIn(int no) {
	return this->set[no - 1];
}
//
void CardsSet::put(Card k) {
	this->set[num++] = k; // ajouter la carte
}
//
int Player::play() {
	bool AjoutDeCarte = true;
	char answer[3];
	int points = 0;

	if (!this->computer) {
		// obtenir la carte initiale retir�e
		this->inHand.put(this->packet.lookIn(this->packet.numCards() + 1)); // +1 car le nombre de cartes dans le paquet est r�duit
		points = this->countPoints();
		cout << "Your score is " << points << " points." << endl;
	}
	else {
		cout << endl << "Computer is playing ..." << endl << endl;
	}
	
	while (AjoutDeCarte && points < 21) {

		if (!this->computer) { // l'utilisateur joue
			cout << "Any additional card ?" << endl;
			cin >> answer;
			AjoutDeCarte = answer[0] == 'y';

			if (AjoutDeCarte) {

				this->inHand.put(this->packet.take());
				// comptage des points
				points = this->countPoints();
				cout << "Your score is " << points << " points." << endl;

			}
			else {
				AjoutDeCarte = false;
			}
		}
		else { // la machine joue
			this->inHand.put(this->packet.take());
			// comptage des points
			points = this->countPoints();

			cout << endl << "Computer score is " << points << " points." << endl;

			srand(time(0)); // nombres al�atoires produits
			string reponsesPoss = "yn"; // unique reponses accepter y / n
			//
			int i_rep = rand() % 2;
			answer[0] = reponsesPoss[i_rep];
			AjoutDeCarte = answer[0] == 'y';

			if (AjoutDeCarte) {

				this->inHand.put(this->packet.take());
				// comptage des points
				points = this->countPoints();

				cout << "Computer score is " << points << " points." << endl;

			}
			else {
				AjoutDeCarte = false;
			}

		}

	}

	this->inHand.empty(); // vider le nombre de cartes en main
	if (this->computer) {
		cout << endl;
	}
	return points;
}

int Player::countPoints() {

	int totalPoints = 0;
	int numOfAce = 0;  // comptez le nombre de As trouv� pour �valuer les points

	// comptez les points

	for (int i = 1; i <= this->inHand.numCards(); i++) {
		Card carteEnMain = this->inHand.lookIn(i); // obtenir la carte correspondante
		totalPoints += carteEnMain.value();       // ajouter la valeur
		if (carteEnMain.value() == 1) numOfAce++; // une carte As a �t� trouv�e
	}

	// si total points >= 21 le As compte pour 1 
	// sinon il compte pour 14
	if (totalPoints < 21)
	{
		totalPoints -= 1 * numOfAce;
		totalPoints += 14 * numOfAce; 
	}

	return totalPoints;
}

int main() {
	CardsSet packet;
	Player you(packet, false);
	Player me(packet, true);
	char answer[3];
	bool continuous = true;
	cout << "Hello! " << endl;
	while (continuous)
	{
		cout << "A new game? " << endl;
		cin >> answer;
		continuous = answer[0] == 'y';
		if (continuous)
		{
			packet.novSet();
			packet.shuffle();
			packet.take();
			int p1 = you.play();
			if (p1 > 21) {
				cout << "You lost! " << endl;
			}
			else if (p1 == 21) {
				cout << "You won! " << endl;
			}
			else // the computer must play
			{
				int p2 = me.play();
				if (p2 <= 21 && p2 >= p1) {
					cout << "You lost! " << endl;
				}
				else {
					cout << "You won! " << endl;
				}
			}
		}
	}
	return 0;
}

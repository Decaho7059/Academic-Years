%Partie 2

[x,f]=audioread('Audio1.wav');
n=(0:1:length(x)-1)/f;
figure;
stem(n,x);
title('Signal audio de Audio1.wav');
sound(x,f);

%---------------------------------------
%Partie 3

%interval
n=0:1:1000;

figure;
h=0.1*(0.99.^(n)); %reponse impulsionnelle
subplot(211);
y=conv(x,h);%Calcul de la convolution avec la fonction conv
n1=(0:1:length(y)-1)/f; %Valeurs pour la convolution
stem(n1,y);
title('Signal y[n] avec la fonction conv');
sound(y,f);

subplot(212);
z=filter(h,1,x);%Calcul de la convolution avec filter
n2=(0:1:length(z)-1)/f; %Valeurs pour la convolution
stem(n2,z);
title('Signal y[n] avec la fonction filter');
sound(z,f); %jouer l'audio recupere

%Partie 1

%vecteur
b = [1 0 0];
a = [1 -5/6 1/6];

%intervals
n = 0:1:100;

h1 = impz(b,a,n);  %calcul de la reponse impulsionnel en temps discret
subplot(221);
stem(n,h1);
axis([-3 11 0 1.1]);
title('Reponse impulsionnelle');
grid on;

%resultat theorique
h2 = (3*(1/2).^n)-(2*(1/3).^n);
subplot(222);
stem(n, h2);
title('resultat theorique');
grid on;

%Partie 2
x=(1-(0.9).^(n)); %entree
y=filter(b,a,x); %resultat de la convolution en temps discret
subplot(223);
stem(n,y);
title('Sortie y[n] du systeme');
grid on;
%Partie 1

% intervals
dt = 0.001;
t = 0:dt:10; 

% vecteurs
b = [0 0 1]; 
a = [1 5 6]; 

h1 = impulse(b,a,t);  
subplot(221);
plot(t,h1);
axis([0 10 -0.05 0.20]);
title('Reponse impulsionnelle'); 
grid on; 

%resultat theorique
h2 = exp(-2*t) - exp(-3*t);
subplot(222);
plot(t,h2);
title('resultat theorique')
grid on;

% Partie 2

x=1-exp(-3*t); % entre
y=lsim(b,a,x,t); %sortie
subplot(223);
plot(t,y); 
title('Sortie y(t) du systeme'); 
grid on; 
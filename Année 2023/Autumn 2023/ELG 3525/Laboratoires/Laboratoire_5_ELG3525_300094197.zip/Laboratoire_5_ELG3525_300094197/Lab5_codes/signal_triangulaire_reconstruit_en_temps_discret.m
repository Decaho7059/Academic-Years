%Signal triangulaire reconstruit avec la serie de Fourier

%les coefficients de la serie de Fourier sont : 
a0 = 0.5;
a1 = -0.20944;
a_m1 = -0.20944;
a2 = 0;
a_m2 = 0;
a3 = -0.03056;
a_m3 = -0.03056;
a4 = 0;
a_m4 = 0;
a5 = -0.02;
N = 10;

%interval
n = 0 : 1 : 10;

%equation de la serie de fourier
x = (a_m4*exp(1i*(-4)*(2*pi/N)*n))+(a_m3*exp(1i*(-3)*(2*pi/N)*n))+...
    (a_m2*exp(1i*(-2)*(2*pi/N)*n))+(a_m1*exp(1i*(-1)*(2*pi/N)*n))+...
    (a0*exp(1i*0*(2*pi/N)*n))+(a1*exp(1i*1*(2*pi/N)*n))+...
    (a2*exp(1i*2*(2*pi/N)*n))+(a3*exp(1i*3*(2*pi/N)*n))+...
    (a4*exp(1i*4*(2*pi/N)*n))+(a5*exp(1i*5*(2*pi/N)*n));


stem(n, x, 'red');
xlabel('n(ech)');
ylabel('x[n]');
title('signal triangulaire reconstruit, perioide N = 10 ');
grid on;

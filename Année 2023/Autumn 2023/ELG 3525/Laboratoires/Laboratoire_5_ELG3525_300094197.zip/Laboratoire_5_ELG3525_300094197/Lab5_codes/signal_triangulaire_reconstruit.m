%signal triangulaire reconstruit avec la serie de Fourier
syms k t1
T = 2;
% x(t) obtenu pour Na = 7 (nombre d'harmoniques)
%en utilisant symsum pour effectuer la somme
Na1 = 7;
x1 = 0.5+symsum((abs(((2*sin(k*pi/2))/(1i*((k*pi).^2)))*exp(-1i*k*pi/2)))* ...
    cos((k*2*(pi/T)*t1)+angle(((2*sin(k*pi/2))/(1i*((k*pi).^2)))*exp(-1i*k*pi/2))),k,1,(Na1-1)/2);

figure(1);
nexttile
fplot(x1, [-1.5 1.5], 'red')
xlabel('t(sec)');
ylabel('x(t)');
title('Signal triangulaire reconstruit avec Na = 7');
grid on;

% x(t) obtenu pour Na = 21
Na2 = 21;
x2 = 0.5+symsum((abs(((2*sin(k*pi/2))/(1i*((k*pi).^2)))*exp(-1i*k*pi/2)))* ...
    cos((k*2*(pi/T)*t1)+angle(((2*sin(k*pi/2))/(1i*((k*pi).^2)))*exp(-1i*k*pi/2))),k,1,(Na2-1)/2);


nexttile
fplot(x2, [-1.5 1.5], 'green')
xlabel('t(sec)');
ylabel('x(t)');
title('Signal triangulaire reconstruit avec Na = 21');
grid on;

% x(t) obtenu pour Na = 201
Na3 = 201;
x3 = 0.5+symsum((abs(((2*sin(k*pi/2))/(1i*((k*pi).^2)))*exp(-1i*k*pi/2)))* ...
    cos((k*2*(pi/T)*t1)+angle(((2*sin(k*pi/2))/(1i*((k*pi).^2)))*exp(-1i*k*pi/2))),k,1,(Na3-1)/2);

nexttile
fplot(x3, [-1.5 1.5], 'blue')
xlabel('t(sec)');
ylabel('x(t)');
title('Signal triangulaire reconstruit avec Na = 201');
grid on;

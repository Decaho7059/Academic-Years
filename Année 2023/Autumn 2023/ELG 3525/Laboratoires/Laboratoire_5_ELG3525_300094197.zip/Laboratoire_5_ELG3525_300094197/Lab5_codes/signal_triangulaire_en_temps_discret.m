%Signal triangulaire, periode N = 10
N = 10;
n = 0 : 1 : 20;

x = 0.5 + (sawtooth((2*pi/N) * n, 1/2)) / 2; %equation du signal triangulaire

stem(n, x, 'red');
xlabel('n(ech)');
ylabel('x[n]');
title('signal triangulaire, periode N = 10 ');
grid on;


%signal triangulaire, periode de T=2
T = 2;
fq = 1000;
t = -1.5 : 1/fq : 1.5;

x = 0.5 + (sawtooth((2*pi/T)*t, 1/2))/2;  %equation du signal triangulaire

plot(t, x, 'red');
xlabel('t(sec)');
ylabel('x(t)');
title('Signal triangulaire, periode T=2');
grid on;


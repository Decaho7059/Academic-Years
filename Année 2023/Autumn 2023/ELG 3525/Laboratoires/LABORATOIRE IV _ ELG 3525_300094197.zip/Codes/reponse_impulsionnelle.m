%coefficiens du systemes LTI
a1 =[1,-5/6,1/6];
a2 = [1,-5/7,1/7];
b1 = [1,0,0];
b2 = [1,0,0];

%Intervals
n=0:1:20; %temps discret

%reponses impulsionnelles
h1=impz(b1,a1,n);
h2=impz(b2,a2,n);

%convolution
h=conv(h1,h2);

figure();
stem(h,'red');
xlabel('temps n');
title('Reponse impulsionnelle equivalente');

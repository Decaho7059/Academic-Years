%p2_a
%Intervals
dt = 0.01;
t=0:dt:60; %temps continu

%coefficients du system LTI
b1 = 1;
a1 =[1,-5,4];

%reponse impulaionnelle
h1=impulse(b1,a1,t);
subplot(221);
plot(t,h1,'green');
xlabel('temps t');
title('Systeme h1 initialement au repos');

%--------------------------------------------------------------
%p2_b

%coefficients du system LTI
b2 = 1;
a2 = [1,5,4];

%reponse impulaionnelle
h2=impulse(b2,a2,t);
subplot(223);
plot(t,h2,'red');
xlabel('temps t');
title('Systeme h2 initialement au repos');

%--------------------------------------------------------------------
%p2_c
%Intervals
n=0:1:60; %temps discret

%coefficients du system LTI
b3 = [1,0,0];
a3 =[1,0,-1/4];

%reponse impulaionnelle
h3=impz(b3,a3,n);
subplot(222);
stem(n,h3,'blue');
xlabel('temps n');
title('Systeme h3 initialement au repos');

%----------------------------------------------------
%p2_d
%coefficients du system LTI
b4 = [1,0,0];
a4 =[1,3/2,-1];

%reponse impulaionnelle
h=impz(b4,a4,n);
subplot(224);
stem(n,h,'black');
xlabel('temps n');
title('Systeme h4 initialement au repos');

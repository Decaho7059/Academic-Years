[x,fs] = audioread('Audio1.wav');%Récupération de l’audio ‘Audio1.wav’

%intervals
n1=(0:length(x)-1)/fs; %taille de l'audio
n = (0:1000); % En temps discret

%coefficients
a = 1;
b = [10;-99/10];

%reponse impulsionnelle
h1 = 0.1*(0.99).^(n); % reponse de la 1er impulsion 
h2=impz(b,a,n); %reponse impulsionnelle du systeme inverse

%methode 1
conv_h = conv(h1,h2); %convolution - en utilisant les reponses de 2 systeme

%methode 2
subplot(221);
stem(x);
title('Signal audio');
sound(x);%ecoute de l'audio

y1 = conv(x,h1);%Convolution la 1ere réponse impulsionelle
subplot(222);
stem(conv_h);
title('reponse impulsionnelle a l''aide de 2 systemes');

y2 = conv(y1,h2); %Convolution la réponse impulsionelle du système inverse
axis([0 100 -1 1]); %echelle
subplot(223);
stem(y2);
title('reponse impulsionnelle en appliquant la sortie du 1er systeme');
sound(y2); %ecoute de l'audio
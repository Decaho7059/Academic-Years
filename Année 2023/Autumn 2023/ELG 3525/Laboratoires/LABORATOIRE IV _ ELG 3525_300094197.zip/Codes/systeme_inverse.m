%Intervals
n=0:1:60; %temps discret

%coefficients du system LTI
b=1;
a=[1,-5/6,1/6];

b1=[1/6,-5/6,1];
a1=1;

b2=[1,-5/6,1/6];
a2=1;

b3=1;
a3=[1/6,-5/6,1];

%reponse impulaionnelle
h=impz(b,a,n);
figure;

h1=impz(b1,a1,n);
conv_h1=conv(h,h1); %convolution
subplot(221);
stem(conv_h1);
title('systeme liste LTI (a)');

h2=impz(b2,a2,n);
conv_h2=conv(h,h2); %convolution
subplot(222);
stem(conv_h2,'green');
xlabel('temps n');
title('systeme liste LTI (b)');

h3=impz(b3,a3,n);
conv_h3=conv(h,h3); %convolution
subplot(223);
stem(conv_h3,'red');
xlabel('temps n');
title('systeme liste LTI (c)');


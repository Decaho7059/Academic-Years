[x,fs] = audioread('noisy_audio.wav'); 

Xw1 = fft(x,max(1001,length(x))); % Transformee de fourier du signal
Xw1 = fftshift(Xw1);
N1 = length(Xw1); 
k1 = -(N1-1)/2:1:(N1-1)/2;
w1=k1*2*pi/N1; 
[b1,a1] = ellip(6,0.5,100,[0.05 0.09],'stop'); %implemente le filtre
%W = 0.22/pi => [0.07]
a = filter(b1,a1,x); % filtre stoppe-bande  

%sound(x,fs); % ecouter le signal
figure;
freqz(b1,a1);
figure;
plot(w1,20*log10(abs(Xw1)), 'blue'); 
title('Magnitude de la transformee de Fourier du signal avec bruit');
xlabel('rad/ech.');
axis([-3.1415 3.1415 -40 90]); %echelle


[b2,a2] = ellip(8,0.5,100,[0.55 0.75],'stop'); %implemente le filtre
b = filter(b2,a2,a); % filtre stoppe-bande
figure;
freqz(b2,a2);
Xw2 = fft(b,max(1001,length(b))); % Transformee de fourier du signal
Xw2 = fftshift(Xw2);
N2 = length(Xw2); 
k2 = -(N2-1)/2:1:(N2-1)/2; 
w2=k2*2*pi/N2; 

figure;
plot(w2,20*log10(abs(Xw2)), 'red');
title('Magnitude de la transformee de Fourier du signal sans bruit');
xlabel('rad/ech.');
axis([-3.1415 3.1415 -40 90]);%echelle

sound(b, fs);
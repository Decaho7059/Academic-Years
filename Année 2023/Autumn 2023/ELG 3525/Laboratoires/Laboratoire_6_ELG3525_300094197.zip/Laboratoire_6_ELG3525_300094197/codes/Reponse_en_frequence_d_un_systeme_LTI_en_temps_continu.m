%valeurs de l'eq diff
b0=121868727358.1180;
a3=1;
a2=6209.9310;
a1=48890434.5196;
a0=121868727358.1180;

a = [a3 a2 a1 a0];
b = b0;

k = tiledlayout(2,1);

%reponse frequentielle du systeme
[h, w] = freqs(b, a); %matrice decrivant les coef de sortie et d'entree

%amplitude de la reponse en freq
figure(1)
nexttile;
plot(w, abs(h), 'red');
title('Magnitude de la reponse en frequence');
xlabel('rad./sec.');

%phase de la reponse en frequence
nexttile;
plot(w,angle(h),'green');
title('Phase de la reponse en frequence');
xlabel('rad./sec.');

filename = 'Audio1_LP.wav';

[x, fs] = audioread(filename);
dt = 1/fs;  %interval de lecture

%Partie 3a
%Affichez la transformer de Fourier de x(t)=(X(jw))
Xw = fft(x,max(1001, length(x)))*dt;  % minimum de 1001 val calculer
Xw = fftshift(Xw); %expression d'une fonction continue
Nfft = length(Xw);
k = -(Nfft - 1)/2:1:(Nfft - 1)/2; %avec Nfft suppose impair ici
w = k*2*pi/Nfft/dt;
figure(1);
nexttile;
plot(w, abs(Xw),'blue');
title('Magnitude de la transformer de Fourier');
xlabel('rad./sec.');

% Partie b
% Ecouter le signal moduler y(t) et afficher sa transformer de Fourier

f1 = 4000;
length(x); 
t = 0:dt:((length(x) - 1)*dt);
y = sin(2*pi*f1*t);
y1 = rot90(y); 
y = x .* y1;   

Yw = fft(y, max(1001, length(y))) * dt;
Yw = fftshift(Yw);
Nfft1 = length(Yw);
k1 = -(Nfft1 - 1)/2:1:(Nfft1 - 1)/2;
w1 = k1 * 2 * pi / Nfft1 / dt;

nexttile;
plot(w, abs(Yw), 'red');
title('Magnitude avec modulation de la transformer de Fourier');
xlabel('rad./sec.');


%Partie c
%Ecouter le signal demoduler z(t) et afficher sa transformer de Fourier

%valeurs de l'eq diff
b0=121868727358.1180;
a3=1;
a2=6209.9310;
a1=48890434.5196;
a0=121868727358.1180;

a = [a3 a2 a1 a0];
b = b0;

yy = sin(2*pi*(-f1)*t);
y0 = rot90(yy);
y3 = y.*y0;
z=lsim(b,a,y3,t);
Xw = fft(z,max(1001, length(x)))*dt;
Xw = fftshift(Xw);
Nfft = length(Xw);
k=-(Nfft -1)/2:1:(Nfft - 1)/2;
w = k*2*pi/Nfft/dt;

nexttile;
plot(w,abs(Xw),'blue');
title('Magnitude avec demodulation de la transformer de Fourier');
xlabel('rad./sec.');


%intervals
dt = 0.05;
t = 0:dt:10;
wo = 5;

x = sinc((wo/pi)*(t-5))*(wo/pi);

%code de la transformer de fourier
Xw = fft(x,max(1001,length(x)))*dt;

%expression de la fonction continue
Xw=fftshift(Xw);
Nfft=length(Xw);
k=-(Nfft - 1)/2:1:(Nfft - 1)/2;  %avec Nfft impaire
w=k*2*pi/Nfft/dt;

nexttile;
plot(w,abs(Xw),'red');
title('Magnitude de la transformer de Fourier');
xlabel('rad./sec.');

%affichage en phase
nexttile;
plot(w, angle(Xw), 'blue');  % Utilisation de la fonction angle pour extraire la phase
title('Phase de la transformee de Fourier');
xlabel('rad./sec.')
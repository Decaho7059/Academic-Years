%intervals
dt=0.01;
t = 0:dt:3;

% fréquence en Hz
f0=1; 
f1=-1;

%signaux
z1=exp(j*2*pi*f0*t); %positive
z2=exp(j*2*pi*f1*t); %negative
x1=cos(2*pi*f0*t);
x2=sin(2*pi*f0*t);

figure;
subplot(2,2,1);
plot3(t,real(z1),imag(z1),'red');
view(+37.5,30);
grid on;
xlabel('temps(s)');
ylabel('Amplitude');
title('Signal avec une frequence positive');

subplot(2,2,2);
plot3(t,real(z2),imag(z2),'blue');
view(+37.5,30);
grid on;
xlabel('temps(s)');
ylabel('Amplitude');
title('Signal avec une frequence negative');

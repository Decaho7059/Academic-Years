%intervals temps continu
dt=0.01;
t=0:dt:80;

%le pas voulu
f1=0.4;
f2=0.3;

%frequence angulaire
w1=2*pi*f1;
w2=2*pi*f2;

%fonctions
x1=sin(w1*t);
x2=sin(w2*t);
x3=x1+x2;

subplot(311);
plot(t,x1);
title('signal sinusoidal periodique 1');

subplot(312);
plot(t,x2);
title('signal sinuso�dal periodique 1');

subplot(313);
plot(t,x3,'red');
title('signal sinusoidal avec periode le PPCM');
grid on;

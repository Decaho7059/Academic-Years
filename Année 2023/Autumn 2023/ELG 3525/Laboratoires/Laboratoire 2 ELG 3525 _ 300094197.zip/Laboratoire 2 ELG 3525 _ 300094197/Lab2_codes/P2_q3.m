%intervals temps discret
n=0:1:50;

%frequence angulaire
w1=5/12*(2*pi);
w2=3/12*(2*pi);

%fonctions
x1=sin(w1*n);
x2=sin(w2*n);


subplot(211);
stem(n,x1, 'blue');
title('Signal x1 periodique avec N=12 constant mais m=5 different');

subplot(212);
stem(n,x2,'red');
title('Signal x1 periodique avec N=12 constant mais m=3 different');
grid on;

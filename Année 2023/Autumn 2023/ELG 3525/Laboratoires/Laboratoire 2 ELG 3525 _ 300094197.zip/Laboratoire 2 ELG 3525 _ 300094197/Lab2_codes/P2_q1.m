%frequence angulaire
w1 = pi/4;
w2=3;
w3 = sqrt(5);

%intervals
dt=0.01;
t=0:dt:20;

%fonctions
x1=sin(w1*t);
x2=sin(w2*t);
x3=sin(w3*t);

figure

subplot(311);
plot(t,x1,'red');
title('Signal periodique avec w fraction de pi');
xlabel('temps(s)');


subplot(312);
plot(t,x2,'black');
title('Signal periodique avec w un entier');
xlabel('temps(s)');

subplot(313);
plot(t,x3);
title('Signal periodique avec w un irrationel');
xlabel('temps(s)');



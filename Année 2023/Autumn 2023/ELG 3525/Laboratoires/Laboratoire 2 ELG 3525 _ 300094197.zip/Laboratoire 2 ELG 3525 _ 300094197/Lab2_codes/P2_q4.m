%intervals temps discret
n=0:1:50;

%frequence angulaire
w1=7/10*(2*pi);
w2=7/10*(2*pi)+(2*pi);

%fonctions
x1=sin(w1*n);
x2=sin(w2*n);

subplot(211);
stem(n,x1,'black');
title('Signal x1 avec w0=7/10*(2*pi)');

subplot(212);
stem(n,x2,'red');
title('Signal x2 avec w0=7/10*(2*pi) + ajout de 2pi');
%intervals temps continu
dt=0.01;
t=0:dt:80;

%le pas voulu
f1=0.4;
f2=sqrt(0.7);

%fréquence angulaire
w1=2*pi*f1;
w2=2*pi*f2;

%fonctions
x1=sin(w1*t);
x2=sin(w2*t);
x3=x1+x2;

subplot(311);
plot(t,x1);
title('Signal périodique');

subplot(312);
plot(t,x2);
title('Signal périodique');

subplot(313);
plot(t,x3,'red');
title('Signal non périodique ayant un PPCM différents');
grid on;
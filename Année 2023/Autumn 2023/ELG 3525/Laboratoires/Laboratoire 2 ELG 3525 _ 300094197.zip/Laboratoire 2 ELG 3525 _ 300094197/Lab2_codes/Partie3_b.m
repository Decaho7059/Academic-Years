%intervals
dt=0.01;
t = 0:dt:3;
t1 = -1:dt:1;

% fréquence en Hz
f0=1; 
f1=-1;

%signaux
z1=exp(j*2*pi*f0*t); %positive
z2=exp(j*2*pi*f1*t); %negative
x1=cos(2*pi*f0*t);
x2=sin(2*pi*f0*t);

figure;
subplot(2,2,1);
plot(t,real(z1),'red');
xlabel('temps(s)');
ylabel('Amplitude');
title('Signal de la partie reel ');

subplot(2,2,2);
plot(t,x1,'blue');
xlabel('temps(s)');
ylabel('Amplitude');
title('Signal x1 avec une frequence negative');

subplot(2,2,3);
plot(t,imag(z1),'green');
xlabel('temps(s)');
ylabel('Amplitude');
title('Signal de la partie imaginaire');

subplot(2,2,4);
plot(t,x2,'black');
xlabel('temps(s)');
ylabel('Amplitude');
title('Signal de la partie imaginaire');

% Creer le son a partir de la fonction
n=0:1:16000;
y=sin(2*pi*0.1*n)+sin(2*pi*0.2*n);

% Normalisation du signal audio
y = y / max(abs(y)); % Normalisons le signal pour qu'il reste entre -1 et 1

% Frequence d'echantillonnage
fq=8000;
sound(y,fq)

% Ecrire l'audio
Audio_name ='P1_Lab2.wav';
audiowrite(Audio_name,y,fq);

% lecture de l'audio
clear fq
[z,fq]=audioread(Audio_name);

% ecouter le son produit
sound(z,fq)

% Affihage du graphe
pause(1)
figure
subplot(2,1,1)
stem(n(1:100),y(1:100),'blue')
grid()
title('Son produit')
xlabel('n')
ylabel('y[n]')

subplot(2,1,2)
stem(n(1:100),z(1:100),'red')
grid()
title('lecture du son')
xlabel('n')
ylabel('z[n]')

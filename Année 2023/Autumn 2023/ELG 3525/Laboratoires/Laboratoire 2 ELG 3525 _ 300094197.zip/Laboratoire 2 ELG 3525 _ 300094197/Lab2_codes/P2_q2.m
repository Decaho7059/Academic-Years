%intervals temps discret
n=0:1:50;

%frequence angulaire
w1=2/4*(2*pi);
w2=7/8*(2*pi);

%fonctions
x1=sin(w1*n);
x2=sin(w2*n);


subplot(211);
stem(n,x1,'blue');
title('Signal non periodique avec w0=(m/N)*2*pi avec facteur commun');
xlabel('temps(s)');

subplot(212);
stem(n,x2,'green');
title('Signal periodique avec w0=(m/N)*2*pi sans facteur commun');
xlabel('temps(s)');


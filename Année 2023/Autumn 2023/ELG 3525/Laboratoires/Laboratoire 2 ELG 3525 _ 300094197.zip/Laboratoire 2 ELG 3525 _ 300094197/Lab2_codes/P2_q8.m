%intervals temps discret
n=0:1:50;

%fréquence angulaire
w1=2*pi*3/7;
w2=0.3;

%fonctions
x1=sin(w1*n);
x2=sin(w2*n);
x3 = x1+x2;


subplot(311);
stem(n,x1);
title('signal périodique');

subplot(312);
stem(n,x2);
title('signal non périodique');

subplot(313);
stem(n,x3,'red');
title('Signal non périodique resultant');
grid on;
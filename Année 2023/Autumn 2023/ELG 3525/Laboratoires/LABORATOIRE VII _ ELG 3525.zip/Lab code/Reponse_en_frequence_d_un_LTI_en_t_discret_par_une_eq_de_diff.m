[x,fs] = audioread('Audio1.wav');
Xw1 = fft(x,max(1001, length(x)));
Xw1 = fftshift(Xw1);
N=length(Xw1);
k=-(N-1)/2:1:(N-1)/2;
w=k*2*pi/N;
figure;
nexttile;
stem(w, abs(Xw1));
title("magnitude des coeffs de Fourier de l'entree");
xlabel('rad./ech.');

%---------

a = [1 -0.99];
b = 0.1;
[h, w]=  freqz(b,a);
nexttile;
plot(w,abs(h),'blue');
title("magnitude des coeffs de Fourier de la reponse impulsionnelle");
xlabel('rad./ech.');

%------------

y = filter(b,a,x);
Xw2 = fft(y,max(1001, length(x)));
Xw2 = fftshift(Xw2);
N=length(Xw2);
k=-(N-1)/2:1:(N-1)/2;
w=k*2*pi/N;
nexttile;
stem(w,abs(Xw2));
title("magnitude des coeffs de Fourier de la sortie du systeme");
xlabel('rad./ech.');

c = 1;
for t = 1:1:21
    x(c)= c;
    c=c+1;
end

c = 1;
for t = 1:1:21
    x1(c)= c;
    c=c+20;
end

kk = tiledlayout(2,1);

%code pour la transformer de Fourier x[n] non periodique
Xw=fft(x,max(1001,length(x))); % un minimum de 101 valeur calculer
Xw=fftshift(Xw);
Nfft=length(Xw);
k=-(Nfft-1)/2:1:(Nfft-1)/2;
w = k*2*pi/Nfft;
figure(1)

nexttile
plot(w,abs(Xw));
title('Magnitude de la transformer de Fourier avec variations rapides');
xlabel('rad./ech.');

nexttile
plot(w,angle(Xw), 'red');
title('phase de la transformer de Fourier avec variations rapides');
xlabel('rad./ech.');



c = 1;
for t = 1:1:21
    x1(c)= c;
    c=c+20;
end

c = 1;
for t = 1:1:21
    x(c)=c;
    c=c+1;
end

kk = tiledlayout(2,1);
% code de la serie de Fourier pour x[n] de periode N
N = length(x);
ak=1/N*fft(x);
ak=fftshift(ak);
k=-(N-1)/2:1:(N-1)/2; %avec N impair
w=k*2*pi/N;

figure(1)
nexttile
stem(w,abs(ak));
title('Magnitude coeffs ak avec variations rapides');
xlabel('rad./ech.');

nexttile
stem(w,angle(ak),'red');
title('phase coeff ak avec variations rapides');
xlabel('rad./ech.');


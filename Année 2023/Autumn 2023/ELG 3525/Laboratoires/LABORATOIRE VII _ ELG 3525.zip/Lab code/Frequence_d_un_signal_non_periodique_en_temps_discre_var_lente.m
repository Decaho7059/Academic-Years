c = 1;
for t = 1:1:21
    x(c)= c;
    c=c+1;
end

c = 1;
for t = 1:1:21
    x1(c)= c;
    c=c+20;
end

kk = tiledlayout(2,1);

Xw1=fft(x1,max(1001,length(x))); % un minimum de 101 valeur calculer
Xw1=fftshift(Xw1);
Nfft=length(Xw1);
k=-(Nfft-1)/2:1:(Nfft-1)/2;
w1 = k*2*pi/Nfft;
figure(1)

nexttile
plot(w1,abs(Xw1));
title('Magnitude de la transformer de Fourier avec variations lente');
xlabel('rad./ech.');

nexttile
plot(w1,angle(Xw1));
title('phase de la transformer de Fourier avec variations lente');
xlabel('rad./ech.');

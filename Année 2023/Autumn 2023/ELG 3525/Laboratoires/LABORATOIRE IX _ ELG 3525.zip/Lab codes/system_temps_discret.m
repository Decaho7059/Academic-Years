% Systeme temps discret d'ordre 1

% coefficients
b = [1 0];
a = [1 -0.5];


figure;
freqz(b, a); % calcul de la reponse frequentielle

figure;
subplot(221);
impz (b, a); % calcul de la reponse impulsionnelle

subplot(222);
stepz(b, a); % calcul de la reponse echellonnee

%---------------------------------------------------

% Systeme temps discret d'ordre 2

% coefficients

r = 0.8;
theta = 0.3;

b = [1 0 0];
a = [1 -2*r*cos(theta) r*r];

figure;
freqz(b, a); % calcul de la reponse frequentielle

figure;
subplot(221);
impz (b, a); % calcul de la reponse impulsionnelle

subplot(222);
stepz(b, a); % calcul de la reponse echellonnee

% Systeme temps continu d'ordre 1
% coefficient
x = [0 1];
y = [1 1];

h = impulse(x, y); % calcul de la reponse impulsionnelle

figure;
freqs(x, y); % calcul de la reponse frequentielle
grid on

figure;
subplot(221);
plot(h);
xlabel('Time (seconds)');
ylabel('Amplitude');
title('Impulse response');
grid on

subplot(222);
step(x, y); % calcul de la reponse echellonnee
grid on

%------------------------------------

% Systeme temps continu d'ordre 2
% coefficient
Wn = 3;
zheta = 0.5;
Wn2 = Wn^2;

x1 = [0 0 Wn2];
x2 = [1 2*zheta*Wn Wn2];

h = impulse(x1, x2); % calcul de la reponse impulsionnelle

figure;
freqs(x1, x2); % calcul de la reponse frequentielle
grid on

figure;
subplot(221);
plot(h);
grid on
xlabel('Time (seconds)');
ylabel('Amplitude');
title('Impulse response');
grid on

subplot(222);
step(x1, x2); % calcul de la reponse echellonnee
grid on


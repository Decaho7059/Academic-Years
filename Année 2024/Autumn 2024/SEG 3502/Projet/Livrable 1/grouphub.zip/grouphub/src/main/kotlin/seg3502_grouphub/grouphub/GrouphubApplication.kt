package seg3502_grouphub.grouphub

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class GrouphubApplication

fun main(args: Array<String>) {
	runApplication<GrouphubApplication>(*args)
}

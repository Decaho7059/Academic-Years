package seg3502_grouphub.grouphub

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GrouphubApplicationTests {

	@Test
	fun contextLoads() {
	}

}

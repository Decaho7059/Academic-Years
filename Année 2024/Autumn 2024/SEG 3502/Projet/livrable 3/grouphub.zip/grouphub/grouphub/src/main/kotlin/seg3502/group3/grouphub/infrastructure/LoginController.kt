package seg3502.group3.grouphub.infrastructure

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.*
import org.springframework.ui.Model

@Controller
class LoginController(private val authenticationService: AuthenticationService) {

    @GetMapping("/login")
    fun login(): String {
        return "html/login.html"
    }

    @GetMapping("/dashboard")
    fun dashboard(): String {
        return "html/dashboard.html"
    }

    @PostMapping("/login")
    fun login(
        @RequestParam username: String,
        @RequestParam password: String,
        model: Model
    ): String {
        return if (authenticationService.authenticate(username, password)) {
            "redirect:html/dashboard.html"
        } else {
            model.addAttribute("error", "Invalid username or password")
            "redirect:html/login.html"
        }
    }

    @GetMapping("/logout")
    fun logout(): String {
        return "redirect:html/login.html"
    }
}

package seg3502.group3.grouphub.domain.user_management

data class User(
    val id: String,
    val name: String,
    val email: String,
    val role: String, // "Student" or "Instructor"
    val password: String

)

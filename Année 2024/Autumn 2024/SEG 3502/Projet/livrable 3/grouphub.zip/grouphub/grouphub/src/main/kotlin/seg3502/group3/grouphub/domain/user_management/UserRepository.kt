package seg3502.group3.grouphub.domain.user_management

interface UserRepository {
    fun save(user: User)
    fun findById(id: String): User?
}

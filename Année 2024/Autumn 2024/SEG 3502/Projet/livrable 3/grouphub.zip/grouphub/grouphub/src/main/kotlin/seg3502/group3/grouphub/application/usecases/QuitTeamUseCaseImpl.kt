package seg3502.group3.grouphub.application.usecases

import seg3502.group3.grouphub.domain.team_creation.TeamRepository

class QuitTeamUseCaseImpl(
    private val teamRepository: TeamRepository
) : QuitTeamUseCase {
    override fun quitTeam(teamId: String, memberId: String) {
        val team = teamRepository.findById(teamId) ?: throw IllegalArgumentException("Team not found")
        if (!team.removeMember(memberId)) throw IllegalArgumentException("Member not in team")
        teamRepository.save(team)
    }
}

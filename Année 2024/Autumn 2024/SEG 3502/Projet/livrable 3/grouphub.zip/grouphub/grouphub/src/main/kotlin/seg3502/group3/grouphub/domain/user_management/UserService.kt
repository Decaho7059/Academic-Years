package seg3502.group3.grouphub.domain.user_management


class UserService(private val userRepository: UserRepository) {

    fun createUser(username: String, name: String, email: String, role: String, password: String) {
        if (userRepository.findById(username) != null) {
            throw IllegalArgumentException("Username already exists")
        }
        return userRepository.save(User(id = username, name = name, email = email, role = role, password = password))
    }
}

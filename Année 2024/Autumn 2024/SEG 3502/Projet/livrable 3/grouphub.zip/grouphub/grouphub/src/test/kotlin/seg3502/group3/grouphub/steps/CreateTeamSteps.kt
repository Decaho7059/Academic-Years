package seg3502.group3.grouphub.steps

import io.cucumber.java.en.Given
import io.cucumber.java.en.Then
import io.cucumber.java.en.When
import org.junit.jupiter.api.Assertions.assertTrue

class CreateTeamSteps {
    private lateinit var teamName: String
    private lateinit var members: List<String>
    private val createdTeams = mutableListOf<String>()

    @Given("a team named {string}")
    fun givenATeamNamed(name: String) {
        teamName = name
    }

    @When("the following members join the team:")
    fun whenTheMembersJoin(members: List<String>) {
        this.members = members
        createdTeams.add(teamName) // Simulates saving the team
    }

    @Then("the team {string} should exist with the following members:")
    fun thenTheTeamShouldExist(name: String, members: List<String>) {
        assertTrue(createdTeams.contains(name))
        // Additional assertions to validate team members can go here
    }
}

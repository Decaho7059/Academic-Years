package seg3502.group3.grouphub.application.usecases

import seg3502.group3.grouphub.domain.team_creation.TeamRepository

class UpdateTeamParametersUseCaseImpl(
    private val teamRepository: TeamRepository
) : UpdateTeamParametersUseCase {
    override fun updateParameters(teamId: String, minSize: Int, maxSize: Int) {
        if (minSize > maxSize) throw IllegalArgumentException("Invalid parameters: minSize > maxSize")
    }
}

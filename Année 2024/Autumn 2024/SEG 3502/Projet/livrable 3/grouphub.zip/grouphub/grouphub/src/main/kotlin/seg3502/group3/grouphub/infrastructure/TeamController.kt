package seg3502.group3.grouphub.infrastructure

import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestParam

class TeamController {

    @GetMapping("/team/create")
    fun createTeamForm(): String {
        return "create_team"
    }

    @PostMapping("/team/create")
    fun createTeam(
        @RequestParam name: String,
        @RequestParam liaison: String,
        model: Model
    ): String {
        // Simulate team creation logic here
        model.addAttribute("message", "Team '$name' created successfully with liaison '$liaison'!")
        return "dashboard"
    }
}

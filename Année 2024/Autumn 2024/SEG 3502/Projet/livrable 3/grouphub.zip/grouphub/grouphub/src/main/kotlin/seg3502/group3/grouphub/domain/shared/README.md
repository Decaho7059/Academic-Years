# Shared Subdomain

## Description
The `shared` subdomain includes utilities and shared functionalities used across other subdomains. These include notifications, system utilities, and helper methods.

## Key Responsibilities
- Provide services for sending notifications (e.g., email).
- Offer utility functions such as ID generation and system-wide settings.
- Serve as a common resource for multiple subdomains.

## Key Classes and Interfaces
- `NotificationService`: Sends email notifications to users.
- `SystemUtils`: Provides utility functions for unique ID generation and other common tasks.

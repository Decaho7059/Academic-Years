package seg3502.group3.grouphub.application.usecases

interface SignOutUseCase {
    fun execute(userId: String)
}

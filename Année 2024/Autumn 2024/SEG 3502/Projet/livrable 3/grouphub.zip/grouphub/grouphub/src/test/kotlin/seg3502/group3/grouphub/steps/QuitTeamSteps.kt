package seg3502.group3.grouphub.steps

import io.cucumber.java.en.Given
import io.cucumber.java.en.Then
import io.cucumber.java.en.When
import org.junit.jupiter.api.Assertions.*
import seg3502.group3.grouphub.domain.team_creation.Team

class QuitTeamSteps {
    private lateinit var team: Team
    private var memberQuit: Boolean = false

    @Given("a team named {string} with members {string}")
    fun givenATeamWithMembers(teamName: String, members: String) {
        val memberList = members.split(", ")
        team = Team(id = "team-1", name = teamName, members = memberList.toMutableList(), liaison = "")
    }

    @When("member {string} quits the team")
    fun whenMemberQuitsTheTeam(memberName: String) {
        memberQuit = team.removeMember(memberName)
    }

    @Then("the team should not include member {string}")
    fun thenTheTeamShouldNotIncludeMember(memberName: String) {
        assertTrue(memberQuit)
        assertFalse(team.members.contains(memberName))
    }
}

package seg3502.group3.grouphub.domain.team_creation

data class TeamCreatedEvent(
    val teamId: String,
    val teamName: String,
    val createdBy: String
)

package seg3502.group3.grouphub.application.usecases

interface CreateTeamUseCase {
    fun createTeam(teamName: String, members: List<String>)
}

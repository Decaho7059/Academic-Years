package seg3502.group3.grouphub.steps

import io.cucumber.java.en.Given
import io.cucumber.java.en.Then
import io.cucumber.java.en.When
import org.junit.jupiter.api.Assertions.*
import seg3502.group3.grouphub.domain.team_creation.Team
import seg3502.group3.grouphub.domain.team_creation.TeamRepository

class AddMemberSteps {
    private val teamRepository = object : TeamRepository {
        private val teams = mutableMapOf<String, Team>()

        override fun save(team: Team) {
            teams[team.id] = team
        }

        override fun findById(id: String): Team? {
            return teams[id]
        }

        override fun findAllIncompleteTeams(): List<Team> = teams.values.toList()
        override fun findByCourseId(courseId: String): List<Team> {
            TODO("Not yet implemented")
        }
    }

    private lateinit var team: Team
    private var memberAdded: Boolean = false

    @Given("a team named {string} with ID {string}")
    fun givenATeamNamed(teamName: String, teamId: String) {
        team = Team(id = teamId, name = teamName, members = mutableListOf(), liaison = "")
        teamRepository.save(team)
    }

    @When("I add a member {string} to the team")
    fun whenIAddAMemberToTheTeam(memberName: String) {
        memberAdded = team.addMember(memberName)
    }

    @Then("the member {string} should be added to the team")
    fun thenTheMemberShouldBeAddedToTheTeam(memberName: String) {
        assertTrue(memberAdded)
        assertTrue(team.members.contains(memberName))
    }
}

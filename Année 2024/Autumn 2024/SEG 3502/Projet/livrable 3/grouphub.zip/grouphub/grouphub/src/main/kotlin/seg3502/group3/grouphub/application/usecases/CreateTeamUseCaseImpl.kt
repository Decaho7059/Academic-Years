package seg3502.group3.grouphub.application.usecases

import seg3502.group3.grouphub.domain.team_creation.TeamFactory
import seg3502.group3.grouphub.domain.team_creation.TeamRepository

class CreateTeamUseCaseImpl(
    private val teamRepository: TeamRepository
) : CreateTeamUseCase {
    override fun createTeam(teamName: String, members: List<String>) {
        val team = TeamFactory.createTeam(
            id = "team-${System.currentTimeMillis()}",
            name = teamName,
            creator = members.first()
        )
        team.members.addAll(members.drop(1))
        teamRepository.save(team)
    }
}

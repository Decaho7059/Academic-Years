package seg3502.group3.grouphub.domain.user_management

data class SignupRequest(
    val username: String,
    val password: String,
    val name: String,
    val email: String,
    val role: String
)

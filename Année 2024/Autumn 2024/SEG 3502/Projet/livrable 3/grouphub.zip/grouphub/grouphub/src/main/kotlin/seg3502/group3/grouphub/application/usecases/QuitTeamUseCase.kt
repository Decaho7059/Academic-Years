package seg3502.group3.grouphub.application.usecases

interface QuitTeamUseCase {
    fun quitTeam(teamId: String, memberId: String)
}

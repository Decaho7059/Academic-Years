package seg3502.group3.grouphub.domain.shared

data class TeamId(val value: String)


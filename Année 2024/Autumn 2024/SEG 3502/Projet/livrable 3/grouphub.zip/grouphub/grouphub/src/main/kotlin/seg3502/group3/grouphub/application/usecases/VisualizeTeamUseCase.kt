package seg3502.group3.grouphub.application.usecases

import seg3502.group3.grouphub.domain.team_creation.Team

interface VisualizeTeamsUseCase {
    fun execute(courseId: String): List<Team>
}

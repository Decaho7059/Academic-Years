package seg3502.group3.grouphub.application.usecases

interface SignInUseCase {
    fun execute(username: String, password: String)
}

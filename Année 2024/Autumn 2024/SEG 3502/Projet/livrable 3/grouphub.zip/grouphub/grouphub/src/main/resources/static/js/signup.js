document.getElementById("signup-btn").addEventListener("click", async function (event) {
    event.preventDefault(); // Prevent form submission by default

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document.getElementById("confirm-password").value.trim();
    const role = document.getElementById("role").value;
    const errorMessage = document.getElementById("error-message");

    // Reset error message
    errorMessage.textContent = "";

    // Validate input
    if (!name || !email || !username || !password || !role) {
        errorMessage.textContent = "All fields are required.";
        return;
    }
    if (password !== confirmPassword) {
        errorMessage.textContent = "Passwords do not match!";
        return;
    }

    try {
        // Send data to the backend
        const response = await fetch("/signup", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ name, email, username, password, role }),
        });

        if (response.ok) {
            // Redirect to login page on success
            window.location.href = "/html/login.html";
        } else {
            const data = await response.json();
            errorMessage.textContent = data.message || "Signup failed.";
        }
    } catch (error) {
        errorMessage.textContent = "An error occurred. Please try again.";
    }
});

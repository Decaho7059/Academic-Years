package seg3502.group3.grouphub.infrastructure

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.web.SecurityFilterChain

@Configuration
class SecurityConfig {

    @Bean
    fun securityFilterChain(http: HttpSecurity): SecurityFilterChain {
        http.csrf().disable()
            .authorizeHttpRequests { auth ->
                auth.requestMatchers("/login", "/signup", "/css/**", "/js/**", "/html/**").permitAll()
                    .anyRequest().authenticated()
            }
            .formLogin { login ->
                login.loginPage("/login").permitAll()
                    .defaultSuccessUrl("/dashboard", true)
            }
            .logout { logout ->
                logout.logoutUrl("/logout")
                    .logoutSuccessUrl("/login")
            }
        return http.build()
    }
}

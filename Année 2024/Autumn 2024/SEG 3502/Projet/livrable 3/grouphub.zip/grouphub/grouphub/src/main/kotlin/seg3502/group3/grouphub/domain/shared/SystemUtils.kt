package seg3502.group3.grouphub.domain.shared

object SystemUtils {
    //fun generateUniqueId(): String {
    //}
}

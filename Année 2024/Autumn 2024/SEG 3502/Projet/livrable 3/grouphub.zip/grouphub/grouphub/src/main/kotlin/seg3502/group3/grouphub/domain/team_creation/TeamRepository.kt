package seg3502.group3.grouphub.domain.team_creation

interface TeamRepository {
    fun save(team: Team)
    fun findById(id: String): Team?
    fun findAllIncompleteTeams(): List<Team>
    abstract fun findByCourseId(courseId: String): List<Team>
}

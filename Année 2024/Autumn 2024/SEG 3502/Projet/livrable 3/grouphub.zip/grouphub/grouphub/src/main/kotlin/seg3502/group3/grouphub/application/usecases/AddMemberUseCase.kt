package seg3502.group3.grouphub.application.usecases

interface AddMemberUseCase {
    fun addMember(teamId: String, memberId: String)
}

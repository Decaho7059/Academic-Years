package seg3502.group3.grouphub.steps

import io.cucumber.java.en.Given
import io.cucumber.java.en.Then
import io.cucumber.java.en.When
import org.junit.jupiter.api.Assertions.*
import seg3502.group3.grouphub.domain.team_creation.Team

class RemoveMemberSteps {
    private lateinit var team: Team
    private var memberRemoved: Boolean = false

    @Given("a team with members {string}")
    fun givenATeamWithMembers(members: String) {
        val memberList = members.split(", ")
        team = Team(id = "team-2", name = "Team Beta", members = memberList.toMutableList(), liaison = "")
    }

    @When("I remove member {string} from the team")
    fun whenIRemoveMemberFromTheTeam(memberName: String) {
        memberRemoved = team.removeMember(memberName)
    }

    @Then("the team should no longer have the member {string}")
    fun thenTheTeamShouldNoLongerHaveTheMember(memberName: String) {
        assertTrue(memberRemoved)
        assertFalse(team.members.contains(memberName))
    }
}

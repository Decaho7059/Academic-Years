package seg3502.group3.grouphub.domain.team_creation

class TeamManagementService(private val teamRepository: TeamRepository) {
    fun canAddMember(teamId: String, maxSize: Int): Boolean {
        val team = teamRepository.findById(teamId) ?: return false
        return team.members.size < maxSize
    }
}

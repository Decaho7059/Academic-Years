package seg3502.group3.grouphub

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class GrouphubApplication

fun main(args: Array<String>) {
	runApplication<GrouphubApplication>(*args)
}

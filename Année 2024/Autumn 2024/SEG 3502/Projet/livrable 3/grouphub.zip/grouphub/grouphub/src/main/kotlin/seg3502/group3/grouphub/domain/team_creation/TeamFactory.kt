package seg3502.group3.grouphub.domain.team_creation

object TeamFactory {
    fun createTeam(id: String, name: String, creator: String): Team {
        return Team(id, name, mutableListOf(creator), creator)
    }
}

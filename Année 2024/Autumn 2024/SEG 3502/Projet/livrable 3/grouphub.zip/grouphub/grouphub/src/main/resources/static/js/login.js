document.getElementById("login-btn").addEventListener("click", function () {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const errorMessage = document.getElementById("error-message");

    // Hardcoded credentials
    const validCredentials = {
        user: "1234",
        admin: "password"
    };

    if (validCredentials[username] === password) {
        window.location.href = "/html/dashboard.html";
    } else {
        errorMessage.style.display = "block";
        errorMessage.textContent = "Invalid username or password";
    }
});

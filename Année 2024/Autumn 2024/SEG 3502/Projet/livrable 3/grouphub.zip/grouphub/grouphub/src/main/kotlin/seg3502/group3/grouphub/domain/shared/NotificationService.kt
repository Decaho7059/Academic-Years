package seg3502.group3.grouphub.domain.shared

interface NotificationService {
    fun sendEmail(to: String, subject: String, body: String)
}

package seg3502.group3.grouphub.infrastructure

import org.springframework.stereotype.Service

@Service
class AuthenticationService {
    private val users = mapOf(
        "admin" to "password",
        "user1" to "1234"
    )

    fun authenticate(username: String, password: String): Boolean {
        println("Authenticating user: $username with password: $password")
        return users[username] == password
    }
}

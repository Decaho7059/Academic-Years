package seg3502.group3.grouphub.application.usecases

class SignOutUseCaseImpl : SignOutUseCase {
    override fun execute(userId: String) {
        // Clear session or JWT token (depending on implementation)
        println("User $userId logged out")
    }
}

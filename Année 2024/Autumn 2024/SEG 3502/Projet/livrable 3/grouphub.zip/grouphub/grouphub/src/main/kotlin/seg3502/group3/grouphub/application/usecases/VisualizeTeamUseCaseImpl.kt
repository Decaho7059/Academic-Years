package seg3502.group3.grouphub.application.usecases

import seg3502.group3.grouphub.domain.team_creation.Team
import seg3502.group3.grouphub.domain.team_creation.TeamRepository

class VisualizeTeamsUseCaseImpl(private val teamRepository: TeamRepository) : VisualizeTeamsUseCase {
    override fun execute(courseId: String): List<Team> {
        return teamRepository.findByCourseId(courseId)
    }
}

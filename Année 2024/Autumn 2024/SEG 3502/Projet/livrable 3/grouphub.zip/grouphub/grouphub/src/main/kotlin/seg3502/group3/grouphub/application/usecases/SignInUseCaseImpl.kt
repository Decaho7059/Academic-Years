package seg3502.group3.grouphub.application.usecases

import seg3502.group3.grouphub.domain.user_management.UserRepository

class SignInUseCaseImpl(private val userRepository: UserRepository) : SignInUseCase {
    override fun execute(username: String, password: String) {
        val user = userRepository.findById(username)
    }
}

package seg3502.group3.grouphub.application.usecases

interface RemoveMemberUseCase {
    fun removeMember(teamId: String, memberId: String)
}

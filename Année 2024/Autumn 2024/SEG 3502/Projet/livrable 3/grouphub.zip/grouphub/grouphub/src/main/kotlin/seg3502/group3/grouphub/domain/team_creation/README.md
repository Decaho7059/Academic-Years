# Team Creation Subdomain

## Description
The `team_creation` subdomain is the core of the Team Management System (TMS). It manages the creation, modification, and lifecycle of teams for assignments and projects. This includes setting up team parameters, managing team members, and ensuring compliance with instructor-defined constraints.

## Key Responsibilities
- Create and manage teams.
- Ensure teams adhere to minimum and maximum size constraints.
- Manage roles within teams, such as assigning the liaison.
- Handle requests for students to join or quit teams.

## Key Classes and Interfaces
- `Team`: Represents a team with its properties (ID, name, members, liaison).
- `TeamRepository`: Provides methods to save and retrieve team data.

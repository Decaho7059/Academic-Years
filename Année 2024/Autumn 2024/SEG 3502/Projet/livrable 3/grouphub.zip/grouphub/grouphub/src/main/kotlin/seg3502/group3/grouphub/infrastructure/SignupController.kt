package seg3502.group3.grouphub.infrastructure

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import seg3502.group3.grouphub.domain.user_management.SignupRequest
import seg3502.group3.grouphub.domain.user_management.UserService

class SignupController(private val userService: UserService) {

    @GetMapping("/signup")
    fun signupPage(): String {
        return "html/signup"
    }

    @PostMapping("/signup")
    fun signup(@RequestBody request: SignupRequest): ResponseEntity<Any> {
        return try {
            userService.createUser(request.username, request.password, request.name, request.email, request.role)
            ResponseEntity.ok("User created successfully")
        } catch (e: Exception) {
            ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mapOf("message" to e.message))
        }
    }

}

package seg3502.group3.grouphub.application.usecases

import seg3502.group3.grouphub.domain.team_creation.TeamRepository

class AddMemberUseCaseImpl(
    private val teamRepository: TeamRepository
) : AddMemberUseCase {
    override fun addMember(teamId: String, memberId: String) {
        val team = teamRepository.findById(teamId) ?: throw IllegalArgumentException("Team not found")
        if (!team.addMember(memberId)) throw IllegalArgumentException("Member already exists")
        teamRepository.save(team)
    }
}

package seg3502.group3.grouphub.application.usecases

interface UpdateTeamParametersUseCase {
    fun updateParameters(teamId: String, minSize: Int, maxSize: Int)
}

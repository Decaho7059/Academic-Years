package seg3502.group3.grouphub

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GrouphubApplicationTests {

	@Test
	fun contextLoads() {
	}

}

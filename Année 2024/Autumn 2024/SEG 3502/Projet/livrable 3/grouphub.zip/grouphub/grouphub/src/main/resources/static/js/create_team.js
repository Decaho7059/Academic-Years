document.getElementById('create-team-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const teamName = document.getElementById('team-name').value;
    const members = document.getElementById('members').value;
    if (!teamName || !members) {
        alert('Please fill in all fields.');
        return;
    }
    alert(`Team "${teamName}" created with members: ${members}`);
});

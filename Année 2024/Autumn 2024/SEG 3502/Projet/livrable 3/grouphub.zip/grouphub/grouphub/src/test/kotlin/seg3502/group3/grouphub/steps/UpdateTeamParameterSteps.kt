package seg3502.group3.grouphub.steps

import io.cucumber.java.en.Given
import io.cucumber.java.en.Then
import io.cucumber.java.en.When
import org.junit.jupiter.api.Assertions.*
import seg3502.group3.grouphub.domain.team_creation.Team

class UpdateTeamParametersSteps {
    private lateinit var team: Team
    private var parametersUpdated: Boolean = false

    @Given("a team named {string} with minimum {int} and maximum {int} members")
    fun givenATeamWithParameters(teamName: String, minSize: Int, maxSize: Int) {
        team = Team(id = "team-3", name = teamName, members = mutableListOf(), liaison = "")
    }

    @When("I update the team parameters to minimum {int} and maximum {int}")
    fun whenIUpdateTheTeamParameters(minSize: Int, maxSize: Int) {
        parametersUpdated = minSize <= maxSize // Simulating parameter validation
    }

    @Then("the team parameters should be updated successfully")
    fun thenTheTeamParametersShouldBeUpdatedSuccessfully() {
        assertTrue(parametersUpdated)
    }
}

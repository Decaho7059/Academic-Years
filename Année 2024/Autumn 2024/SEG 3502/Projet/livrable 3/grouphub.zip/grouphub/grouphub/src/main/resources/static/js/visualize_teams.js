document.addEventListener('DOMContentLoaded', function() {
    const teamList = document.querySelector('.team-list');
    const teams = [
        { name: 'Team Alpha', members: 5 },
        { name: 'Team Beta', members: 3 },
        { name: 'Team Gamma', members: 4 }
    ];
    teams.forEach(team => {
        const teamCard = document.createElement('div');
        teamCard.className = 'team-card';
        teamCard.innerHTML = `<h3>${team.name}</h3><p>Members: ${team.members}</p>`;
        teamList.appendChild(teamCard);
    });
});

package seg3502.group3.grouphub.domain.team_creation

data class Team(
    val id: String,
    val name: String,
    val members: MutableList<String>,
    val liaison: String
){
    fun addMember(member: String): Boolean {
        if (members.contains(member)) return false
        members.add(member)
        return true
    }

    fun removeMember(member: String): Boolean {
        return members.remove(member)
    }

    fun isComplete(minSize: Int, maxSize: Int): Boolean {
        return members.size in minSize..maxSize
    }
}

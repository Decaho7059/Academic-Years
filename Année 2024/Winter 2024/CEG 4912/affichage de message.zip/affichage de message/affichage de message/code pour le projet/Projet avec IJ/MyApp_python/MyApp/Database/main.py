from Database.database_handler import DatabaseHandler

database_handler = DatabaseHandler()

def register():
    print("---Register---")
    username = input("Username : ")
    password = input("Mot de passe : ")

    database_handler.create_person(username, password)

def menu_not_connected():
    while True:
        print("Bienvenue sur DecahoGame !! (non connected)")
        print("Choisissez une option ")
        print("1, Login")
        print("2, S'enregistrer")
        choix = int(input())
        if choix == 2:
            register()


menu_not_connected()
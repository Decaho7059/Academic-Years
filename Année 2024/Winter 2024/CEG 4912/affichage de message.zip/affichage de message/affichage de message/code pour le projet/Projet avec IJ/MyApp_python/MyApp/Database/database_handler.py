import sqlite3

#from pip._internal.resolution.resolvelib.factory import C


class DatabaseHandler():
    def __inti__(self, database_name : str):
        self.con = sqlite3.connect(f"{database_name}")
        self.con.row_factory = sqlite3.Row



    def create_person(self, username: str, password: str):
        cursor = self.con.cursor()
        query = f"INSERT INTO Person (username, password) VALUES ('{username}', '{password}');"
        cursor.execute(query)
        cursor.close()
        self.con.commit()

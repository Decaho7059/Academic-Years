package SEG2106.GUI;

public interface TrafficLightUserInterface {
	public void northGreen();
	public void northYellow();
	public void northRed();
	public void northArrow();
	public void northGreenAndArrow();
	public void southGreen();
	public void southYellow();
	public void southRed();
	public void southArrow();
	public void southGreenAndArrow();
	public void westGreen();
	public void westYellow();
	public void westRed();
	public void westArrow();
	public void westGreenAndArrow();
	public void eastGreen();
	public void eastYellow();
	public void eastRed();
	public void eastArrow();
	public void eastGreenAndArrow();
}

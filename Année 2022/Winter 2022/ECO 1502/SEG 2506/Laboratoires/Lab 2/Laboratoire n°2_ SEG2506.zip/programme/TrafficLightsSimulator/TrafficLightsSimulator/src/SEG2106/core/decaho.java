//
//  package SEG2106.core;
//
//
//  // line 1 "model.ump"
//     public class decaho implements EventHandler {
//
//  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
//  public @interface umplesourcefile{int[] line();String[] file();int[] javaline();int[] length();}
//
//  //------------------------ // MEMBER VARIABLES //------------------------
//
//  //TrafficLight State Machines
//    public enum Status { lowTraffic, moderateTraffic, HighTraffic}
//    public enum StatusLowTraffic { Null, northAndSouthGreenArrow, northAndSouthGreen, northAndSouthYellow, northAndSouthRed, westAndEastYellow }
//    public enum StatusModerateTraffic { Null, northAndGreenArrow, northYellow, southAndGreenArrow, southYellow, westAndEastGreen, westAndEastYellow }
//    public enum StatusHighTraffic { Null, northAndGreenArrow, northYellow, southAndGreenArrow, southYellow, westAndGreenArrow, westAndEastGreen, westAndEastYellow }
//    private Status  status;
//    private StatusLowTraffic statusLowTraffic;
//    private StatusModerateTraffic statusModerateTraffic;
//    private StatusHighTraffic statusHighTraffic;
//
//  //------------------------ // CONSTRUCTOR //------------------------
//
//  private TrafficLightManager trafficLightManager;
//  public void TrafficLight(TrafficLightManager trafficLightManager) {
//    this.trafficLightManager = trafficLightManager;
//
//    setStatusLowTraffic(StatusLowTraffic.Null);
//    setStatusModerateTraffic(StatusModerateTraffic.Null);
//    setStatusHighTraffic(StatusHighTraffic.Null);
//    setStatus(Status.lowTraffic);
//    setStatus(Status.moderateTraffic);
//    setStatus(Status.HighTraffic);
//
//    trafficLightManager.addEventHandler(this);
//  }
//
//
//
//    //------------------------ // INTERFACE //------------------------
//
//  public String getStatusFullName() {
//    String answer = status.toString();
//    if (statusLowTraffic != StatusLowTraffic.Null) { answer += "." + statusLowTraffic.toString(); }
//    if (statusModerateTraffic != StatusModerateTraffic.Null) { answer += "." + statusModerateTraffic.toString(); }
//    if (statusHighTraffic != StatusHighTraffic.Null) { answer += "." + statusHighTraffic.toString(); }
//  return answer;
//  }
//
//  public Status getStatus() { return status; }
//
//  public StatusLowTraffic getStatusLowTraffic() { return statusLowTraffic; }
//
//  public StatusModerateTraffic getStatusModerateTraffic() { return statusModerateTraffic; }
//
//  public StatusHighTraffic getStatusHighTraffic() { return statusHighTraffic; }
//
//  public boolean timerGreen() {
//    boolean wasEventProcessed = false;
//
//    //Status aStatus = status;
//    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
//    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
//    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
//
//    switch (aStatusLowTraffic) {
//      case northAndSouthGreenArrow:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.northAndSouthGreen);
//        wasEventProcessed = true;
//        break;
//      case northAndSouthGreen:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.northAndSouthYellow);
//        wasEventProcessed = true;
//        break;
//      case northAndSouthRed:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.westAndEastYellow);
//        wasEventProcessed = true;
//        break;
//      default:
//        // Other states do respond to this event
//    }
//    switch (aStatusModerateTraffic) {
//      case northAndGreenArrow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.northYellow);
//        wasEventProcessed = true;
//        break;
//      case northYellow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.southAndGreenArrow);
//        wasEventProcessed = true;
//        break;
//      case southYellow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.westAndEastGreen);
//        wasEventProcessed = true;
//        break;
//      case westAndEastYellow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.northAndGreenArrow);
//        wasEventProcessed = true;
//        break;
//      default: // Other states do respond to this event }
//
//        switch (aStatusHighTraffic) {
//          case northAndGreenArrow:
//            exitStatusHighTraffic();
//            setStatusHighTraffic(StatusHighTraffic.northYellow);
//            wasEventProcessed = true;
//            break;
//          case northYellow:
//            exitStatusHighTraffic();
//            setStatusHighTraffic(StatusHighTraffic.southAndGreenArrow);
//            wasEventProcessed = true;
//            break;
//          case southYellow:
//            exitStatusHighTraffic();
//            setStatusHighTraffic(StatusHighTraffic.westAndGreenArrow);
//            wasEventProcessed = true;
//            break;
//          case westAndEastYellow:
//            exitStatusHighTraffic();
//            setStatusHighTraffic(StatusHighTraffic.northAndGreenArrow);
//            wasEventProcessed = true;
//            break;
//          default: // Other states do respond to this event
//        }
//
//
//    }
//    return wasEventProcessed;
//  }
//
//  public boolean timerYellow() {
//    boolean wasEventProcessed = false;
//
//  //Status aStatus = status;
//    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
//    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
//    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
//
//    switch (aStatusLowTraffic) {
//      case northAndSouthYellow:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.northAndSouthRed);
//        wasEventProcessed = true;
//        break;
//      case westAndEastYellow:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.northAndSouthGreenArrow);
//        wasEventProcessed = true;
//        break;
//      default: // Other states do respond to this event
//        }
//        switch (aStatusModerateTraffic) {
//      case southAndGreenArrow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.southYellow);
//        wasEventProcessed = true;
//        break;
//      case westAndEastGreen:
//          exitStatusModerateTraffic();
//          setStatusModerateTraffic(StatusModerateTraffic.westAndEastYellow);
//          wasEventProcessed = true;
//          break;
//      default: // Other states do respond to this event
//        }
//        switch (aStatusHighTraffic) {
//      case southAndGreenArrow:
//        exitStatusHighTraffic();
//        setStatusHighTraffic(StatusHighTraffic.southYellow);
//        wasEventProcessed = true;
//        break;
//      case westAndGreenArrow:
//        exitStatusHighTraffic();
//        setStatusHighTraffic(StatusHighTraffic.westAndEastGreen);
//        wasEventProcessed = true;
//        break;
//      case westAndEastGreen:
//        exitStatusHighTraffic();
//        setStatusHighTraffic(StatusHighTraffic.westAndEastYellow);
//        wasEventProcessed = true;
//        break;
//      default: // Other states do respond to this event
//        }
//        return wasEventProcessed;
//  }
//
//  public void exitStatus() {
//    switch(status) {
//      case lowTraffic:
//        exitStatusLowTraffic();
//        break;
//      case moderateTraffic:
//        exitStatusModerateTraffic();
//        break;
//      case HighTraffic:
//        exitStatusHighTraffic();
//        break;
//    }
//  }
//
//  private void setStatus(Status aStatus) {
//    status = aStatus;
//
//  // entry actions and do activities
//    switch(status) {
//      case lowTraffic:
//        if(statusLowTraffic == StatusLowTraffic.Null){
//          setStatusLowTraffic(StatusLowTraffic.northAndSouthGreenArrow);
//        } break;
//      case moderateTraffic:
//        if (statusModerateTraffic == StatusModerateTraffic.Null) {
//          setStatusModerateTraffic(StatusModerateTraffic.northAndGreenArrow);
//        } break;
//      case HighTraffic:
//        if (statusHighTraffic == StatusHighTraffic.Null) {
//          setStatusHighTraffic(StatusHighTraffic.northAndGreenArrow);
//        } break; }
//  }
//
//  private void exitStatusLowTraffic() {
//    switch(statusLowTraffic) {
//      case northAndSouthGreenArrow:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break;
//      case northAndSouthGreen:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break;
//      case northAndSouthYellow:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break;
//      case northAndSouthRed:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break;
//      case westAndEastYellow:
//          setStatusLowTraffic(StatusLowTraffic.Null);
//          break; }
//  }
//
//  private void exitStatusModerateTraffic() {
//    switch(statusModerateTraffic) {
//      case northAndGreenArrow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case northYellow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case southAndGreenArrow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case southYellow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case westAndEastGreen:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//        case westAndEastYellow:
//          setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break; }
//  }
//
//  private void exitStatusHighTraffic() {
//    switch(statusHighTraffic) {
//      case northAndGreenArrow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case northYellow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case southAndGreenArrow:
//          setStatusHighTraffic(StatusHighTraffic.Null);
//          break;
//      case southYellow:
//            setStatusHighTraffic(StatusHighTraffic.Null);
//            break;
//      case westAndGreenArrow:
//              setStatusHighTraffic(StatusHighTraffic.Null);
//              break;
//      case westAndEastGreen: setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case westAndEastYellow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break; }
//  }
//
//  private void setStatusLowTraffic(StatusLowTraffic aStatusLowTraffic) {
//  statusLowTraffic = aStatusLowTraffic;
//  if (status != Status.lowTraffic && aStatusLowTraffic != StatusLowTraffic.Null) { setStatus(Status.lowTraffic); }
//
//  // entry actions and do activities
//    switch(statusLowTraffic) {
//    case northAndSouthGreenArrow:
//      // line 10 "model.ump"
//      trafficLightManager.northArrow();
//      // line 11 "model.ump"
//      trafficLightManager.southArrow();
//      // line 12 "model.ump"
//      trafficLightManager.westRed();
//      // line 13 "model.ump"
//      trafficLightManager.eastRed();
//      break;
//    case northAndSouthGreen:
//      // line 17"model.ump"
//      trafficLightManager.northGreen();
//      // line 18 "model.ump"
//      trafficLightManager.southGreen();
//      // line 19 "model.ump"
//      trafficLightManager.westRed();
//      // line 20 "model.ump"
//      trafficLightManager.eastRed();
//      break;
//    case northAndSouthYellow:
//      // line 24"model.ump"
//      trafficLightManager.northYellow();
//      // line 25 "model.ump"
//      trafficLightManager.southYellow();
//      // line 26 "model.ump"
//      trafficLightManager.westRed();
//      // line 27 "model.ump"
//      trafficLightManager.eastRed();
//      break;
//    case northAndSouthRed:
//      // line 31"model.ump"
//      trafficLightManager.northRed();
//      // line 32 "model.ump"
//      trafficLightManager.southRed();
//      // line 33 "model.ump"
//      trafficLightManager.westGreen();
//      // line 34 "model.ump"
//      trafficLightManager.eastGreen();
//      // break;
//    case westAndEastYellow:
//      // line 38 "model.ump"
//      trafficLightManager.northRed();
//      // line 39 "model.ump"
//      trafficLightManager.southRed();
//      // line 40 "model.ump"
//      trafficLightManager.westYellow();
//      // line 41 "model.ump"
//      trafficLightManager.eastYellow();
//      break;
//      } }
//
//  private void setStatusModerateTraffic(StatusModerateTraffic aStatusModerateTraffic) {
//    statusModerateTraffic = aStatusModerateTraffic;
//    if (status != Status.moderateTraffic && aStatusModerateTraffic != StatusModerateTraffic.Null) {
//      setStatus(Status.moderateTraffic);
//    }
//
//    // entry actions and do activities
//    switch (statusModerateTraffic) {
//      case northAndGreenArrow:
//        // line 10 "model.ump"
//        trafficLightManager.northGreenAndArrow();
//        // line 11 "model.ump"
//        trafficLightManager.southRed();
//        // line 12 "model.ump"
//        trafficLightManager.westRed();
//        // line 13 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case northYellow:
//        // line 18"model.ump"
//        trafficLightManager.northYellow();
//        // line 19 "model.ump"
//        trafficLightManager.southRed();
//        // line 20 "model.ump"
//        trafficLightManager.westRed();
//        // line 21 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case southAndGreenArrow:
//        // line 26"model.ump"
//        trafficLightManager.northRed();
//        // line 27 "model.ump"
//        trafficLightManager.southGreenAndArrow();
//        // line 28 "model.ump"
//        trafficLightManager.westRed();
//        // line 29 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case southYellow:
//        // line 34"model.ump"
//        trafficLightManager.northRed();
//        // line 35 "model.ump"
//        trafficLightManager.southYellow();
//        // line 36 "model.ump"
//        trafficLightManager.westRed();
//        // line 37 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case westAndEastGreen:
//        // line 42"model.ump"
//        trafficLightManager.northRed();
//        // line 43 "model.ump"
//        trafficLightManager.southRed();
//        // line 44 "model.ump"
//        trafficLightManager.westGreen();
//        // line 45 "model.ump"
//        trafficLightManager.eastGreen();
//        break;
//      case westAndEastYellow:
//        // line 49"model.ump"
//        trafficLightManager.northRed();
//        // line 50 "model.ump"
//        trafficLightManager.southRed();
//        // line 51 "model.ump"
//        trafficLightManager.westYellow();
//        // line 52 "model.ump"
//        trafficLightManager.eastYellow();
//        break;
//
//    }
//
//  }
//
//  private void setStatusHighTraffic(StatusHighTraffic aStatusHighTraffic) {
//    statusHighTraffic = aStatusHighTraffic;
//    if (status != Status.HighTraffic && aStatusHighTraffic != StatusHighTraffic.Null) {
//      setStatus(Status.HighTraffic);
//    }
//
//    // entry actions and do activities
//    switch (statusHighTraffic) {
//      case northAndGreenArrow:
//        // line 10 "model.ump"
//        trafficLightManager.northGreenAndArrow();
//        // line 11 "model.ump"
//        trafficLightManager.southRed();
//        // line 12 "model.ump"
//        trafficLightManager.westRed();
//        // line 13 "model.ump"
//        trafficLightManager.eastRed();
//       break;
//      case northYellow:
//        //line 18"model.ump"
//        trafficLightManager.northYellow();
//        // line 19 "model.ump"
//        trafficLightManager.southRed();
//        // line 20 "model.ump"
//        trafficLightManager.westRed();
//        // line 21 "model.ump"
//        trafficLightManager.eastRed();
//        // break;
//      case southAndGreenArrow:
//        // line 26"model.ump"
//        trafficLightManager.northRed();
//        // line 27 "model.ump"
//        trafficLightManager.southGreenAndArrow();
//        // line 28 "model.ump"
//        trafficLightManager.westRed();
//        // line 29 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case southYellow:
//        // line 34"model.ump"
//        trafficLightManager.northRed();
//        // line 35 "model.ump"
//        trafficLightManager.southYellow();
//        // line 36 "model.ump"
//        trafficLightManager.westRed();
//        // line 37 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case westAndGreenArrow:
//        // line 42"model.ump"
//        trafficLightManager.northRed();
//        // line 43 "model.ump"
//        trafficLightManager.southRed();
//        // line 44 "model.ump"
//        trafficLightManager.westGreenAndArrow();
//        // line 45 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case westAndEastGreen:
//        //  line 49"model.ump"
//        trafficLightManager.northRed();
//        // line 50 "model.ump"
//        trafficLightManager.southRed();
//        // line 51 "model.ump"
//        trafficLightManager.westGreen();
//        // line 52 "model.ump"
//        trafficLightManager.eastGreen();
//        break;
//      case westAndEastYellow:
//        // line 56"model.ump"
//        trafficLightManager.northRed();
//        // line 57 "model.ump"
//        trafficLightManager.southRed();
//        //line 58 "model.ump"
//        trafficLightManager.westYellow();
//        // line 59 "model.ump"
//        trafficLightManager.eastYellow();
//        break;
//       } }
//
//        public void delete () {
//      }
//
//      @Override
//      public boolean moderateTraffic () {
//        // TODO Auto-generated method stub
//        return false;
//      }
//
//      @Override
//      public boolean lowTraffic () {
//        // TODO Auto-generated method stub
//        return false;
//      }
//
//      @Override
//      public boolean highTraffic () {
//        // TODO Auto-generated method stub;
//        return false;
//      }
//     }


//////Next version
//package SEG2106.core;/*PLEASE DO NOT EDIT THIS CODE*/
///*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/
//
//
//import SEG2106.core.EventHandler;
//import SEG2106.core.TrafficLightManager;
//
//// line 2 "model.ump"
//// line 150 "model.ump"
//// line 1 "model.ump"
//
//public class TrafficLight implements EventHandler {
//
//  @java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
//  public @interface umplesourcefile{int[] line();String[] file();int[] javaline();int[] length();}
//
//  //------------------------ // MEMBER VARIABLES //------------------------
//
//  //TrafficLight State Machines
//  public enum Status { lowTraffic, moderateTraffic, HighTraffic}
//  public enum StatusLowTraffic { Null, northAndSouthGreenArrow, northAndSouthGreen, northAndSouthYellow, northAndSouthRed, westAndEastYellow }
//  public enum StatusModerateTraffic { Null, northAndGreenArrow, northYellow, southAndGreenArrow, southYellow, westAndEastGreen, westAndEastYellow }
//  public enum StatusHighTraffic { Null, northAndGreenArrow, northYellow, southAndGreenArrow, southYellow, westAndGreenArrow, westAndEastGreen, westAndEastYellow }
//  private Status  status;
//  private StatusLowTraffic statusLowTraffic;
//  private StatusModerateTraffic statusModerateTraffic;
//  private StatusHighTraffic statusHighTraffic;
//
//  //------------------------ // CONSTRUCTOR //------------------------
//
//  private TrafficLightManager trafficLightManager;
//  public TrafficLight(TrafficLightManager trafficLightManager) {
//    this.trafficLightManager = trafficLightManager;
//
//    setStatusLowTraffic(StatusLowTraffic.Null);
//    setStatusModerateTraffic(StatusModerateTraffic.Null);
//    setStatusHighTraffic(StatusHighTraffic.Null);
//    setStatus(Status.lowTraffic);
//    setStatus(Status.moderateTraffic);
//    setStatus(Status.HighTraffic);
//
//    trafficLightManager.addEventHandler(this);
//  }
//
//
//
//  //------------------------ // INTERFACE //------------------------
//
//  public String getStatusFullName() {
//    String answer = status.toString();
//    if (statusLowTraffic != StatusLowTraffic.Null) { answer += "." + statusLowTraffic.toString(); }
//    if (statusModerateTraffic != StatusModerateTraffic.Null) { answer += "." + statusModerateTraffic.toString(); }
//    if (statusHighTraffic != StatusHighTraffic.Null) { answer += "." + statusHighTraffic.toString(); }
//    return answer;
//  }
//
//  public Status getStatus() { return status; }
//
//  public StatusLowTraffic getStatusLowTraffic() { return statusLowTraffic; }
//
//  public StatusModerateTraffic getStatusModerateTraffic() { return statusModerateTraffic; }
//
//  public StatusHighTraffic getStatusHighTraffic() { return statusHighTraffic; }
//
//  public boolean timerGreen() {
//    boolean wasEventProcessed = false;
//
//    //Status aStatus = status;
//    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
//    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
//    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
//
//    switch (aStatusLowTraffic) {
//      case northAndSouthGreenArrow:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.northAndSouthGreen);
//        wasEventProcessed = true;
//        break;
//      case northAndSouthGreen:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.northAndSouthYellow);
//        wasEventProcessed = true;
//        break;
//      case northAndSouthRed:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.westAndEastYellow);
//        wasEventProcessed = true;
//        break;
//        case westAndEastYellow:
//            exitStatusLowTraffic();
//            setStatusLowTraffic(StatusLowTraffic.northAndSouthGreenArrow);
//            wasEventProcessed = true;
//            break;
//      default:
//        // Other states do respond to this event
//    }
//    switch (aStatusModerateTraffic) {
//      case northAndGreenArrow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.northYellow);
//        wasEventProcessed = true;
//        break;
//      case northYellow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.southAndGreenArrow);
//        wasEventProcessed = true;
//        break;
//      case southYellow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.westAndEastGreen);
//        wasEventProcessed = true;
//        break;
//      case westAndEastYellow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.northAndGreenArrow);
//        wasEventProcessed = true;
//        break;
//      default: // Other states do respond to this event }
//
//        switch (aStatusHighTraffic) {
//          case northAndGreenArrow:
//            exitStatusHighTraffic();
//            setStatusHighTraffic(StatusHighTraffic.northYellow);
//            wasEventProcessed = true;
//            break;
//          case northYellow:
//            exitStatusHighTraffic();
//            setStatusHighTraffic(StatusHighTraffic.southAndGreenArrow);
//            wasEventProcessed = true;
//            break;
//          case southYellow:
//            exitStatusHighTraffic();
//            setStatusHighTraffic(StatusHighTraffic.westAndGreenArrow);
//            wasEventProcessed = true;
//            break;
//          case westAndEastYellow:
//            exitStatusHighTraffic();
//            setStatusHighTraffic(StatusHighTraffic.northAndGreenArrow);
//            wasEventProcessed = true;
//            break;
//          default: // Other states do respond to this event
//        }
//
//
//    }
//    return wasEventProcessed;
//  }
//
//  public boolean timerYellow() {
//    boolean wasEventProcessed = false;
//
//    //Status aStatus = status;
//    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
//    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
//    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
//
//    switch (aStatusLowTraffic) {
//      case northAndSouthYellow:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.northAndSouthRed);
//        wasEventProcessed = true;
//        break;
//      case westAndEastYellow:
//        exitStatusLowTraffic();
//        setStatusLowTraffic(StatusLowTraffic.northAndSouthGreenArrow);
//        wasEventProcessed = true;
//        break;
//      default: // Other states do respond to this event
//    }
//    switch (aStatusModerateTraffic) {
//      case southAndGreenArrow:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.southYellow);
//        wasEventProcessed = true;
//        break;
//      case westAndEastGreen:
//        exitStatusModerateTraffic();
//        setStatusModerateTraffic(StatusModerateTraffic.westAndEastYellow);
//        wasEventProcessed = true;
//        break;
//      default: // Other states do respond to this event
//    }
//    switch (aStatusHighTraffic) {
//      case southAndGreenArrow:
//        exitStatusHighTraffic();
//        setStatusHighTraffic(StatusHighTraffic.southYellow);
//        wasEventProcessed = true;
//        break;
//      case westAndGreenArrow:
//        exitStatusHighTraffic();
//        setStatusHighTraffic(StatusHighTraffic.westAndEastGreen);
//        wasEventProcessed = true;
//        break;
//      case westAndEastGreen:
//        exitStatusHighTraffic();
//        setStatusHighTraffic(StatusHighTraffic.westAndEastYellow);
//        wasEventProcessed = true;
//        break;
//      default: // Other states do respond to this event
//    }
//    return wasEventProcessed;
//  }
//
//  public void exitStatus() {
//    switch(status) {
//      case lowTraffic:
//        exitStatusLowTraffic();
//        break;
//      case moderateTraffic:
//        exitStatusModerateTraffic();
//        break;
//      case HighTraffic:
//        exitStatusHighTraffic();
//        break;
//    }
//  }
//
//  private void setStatus(Status aStatus) {
//    status = aStatus;
//
//    // entry actions and do activities
//    switch(status) {
//      case lowTraffic:
//        if(statusLowTraffic == StatusLowTraffic.Null){
//          setStatusLowTraffic(StatusLowTraffic.northAndSouthGreenArrow);
//        } break;
//      case moderateTraffic:
//        if (statusModerateTraffic == StatusModerateTraffic.Null) {
//          setStatusModerateTraffic(StatusModerateTraffic.northAndGreenArrow);
//        } break;
//      case HighTraffic:
//        if (statusHighTraffic == StatusHighTraffic.Null) {
//          setStatusHighTraffic(StatusHighTraffic.northAndGreenArrow);
//        } break; }
//  }
//
//  private void exitStatusLowTraffic() {
//    switch(statusLowTraffic) {
//      case northAndSouthGreenArrow:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break;
//      case northAndSouthGreen:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break;
//      case northAndSouthYellow:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break;
//      case northAndSouthRed:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break;
//      case westAndEastYellow:
//        setStatusLowTraffic(StatusLowTraffic.Null);
//        break; }
//  }
//
//  private void exitStatusModerateTraffic() {
//    switch(statusModerateTraffic) {
//      case northAndGreenArrow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case northYellow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case southAndGreenArrow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case southYellow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case westAndEastGreen:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break;
//      case westAndEastYellow:
//        setStatusModerateTraffic(StatusModerateTraffic.Null);
//        break; }
//  }
//
//  private void exitStatusHighTraffic() {
//    switch(statusHighTraffic) {
//      case northAndGreenArrow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case northYellow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case southAndGreenArrow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case southYellow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case westAndGreenArrow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case westAndEastGreen: setStatusHighTraffic(StatusHighTraffic.Null);
//        break;
//      case westAndEastYellow:
//        setStatusHighTraffic(StatusHighTraffic.Null);
//        break; }
//  }
//
//  private void setStatusLowTraffic(StatusLowTraffic aStatusLowTraffic) {
//    statusLowTraffic = aStatusLowTraffic;
//    if (status != Status.lowTraffic && aStatusLowTraffic != StatusLowTraffic.Null) { setStatus(Status.lowTraffic); }
//
//    // entry actions and do activities
//    switch(statusLowTraffic) {
//      case northAndSouthGreenArrow:
//        // line 10 "model.ump"
//        trafficLightManager.northArrow();
//        // line 11 "model.ump"
//        trafficLightManager.southArrow();
//        // line 12 "model.ump"
//        trafficLightManager.westRed();
//        // line 13 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case northAndSouthGreen:
//        // line 17"model.ump"
//        trafficLightManager.northGreen();
//        // line 18 "model.ump"
//        trafficLightManager.southGreen();
//        // line 19 "model.ump"
//        trafficLightManager.westRed();
//        // line 20 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case northAndSouthYellow:
//        // line 24"model.ump"
//        trafficLightManager.northYellow();
//        // line 25 "model.ump"
//        trafficLightManager.southYellow();
//        // line 26 "model.ump"
//        trafficLightManager.westRed();
//        // line 27 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case northAndSouthRed:
//        // line 31"model.ump"
//        trafficLightManager.northRed();
//        // line 32 "model.ump"
//        trafficLightManager.southRed();
//        // line 33 "model.ump"
//        trafficLightManager.westGreen();
//        // line 34 "model.ump"
//        trafficLightManager.eastGreen();
//        // break;
//      case westAndEastYellow:
//        // line 38 "model.ump"
//        trafficLightManager.northRed();
//        // line 39 "model.ump"
//        trafficLightManager.southRed();
//        // line 40 "model.ump"
//        trafficLightManager.westYellow();
//        // line 41 "model.ump"
//        trafficLightManager.eastYellow();
//        break;
//    } }
//
//  private void setStatusModerateTraffic(StatusModerateTraffic aStatusModerateTraffic) {
//    statusModerateTraffic = aStatusModerateTraffic;
//    if (status != Status.moderateTraffic && aStatusModerateTraffic != StatusModerateTraffic.Null) {
//      setStatus(Status.moderateTraffic);
//    }
//
//    // entry actions and do activities
//    switch (statusModerateTraffic) {
//      case northAndGreenArrow:
//        // line 10 "model.ump"
//        trafficLightManager.northGreenAndArrow();
//        // line 11 "model.ump"
//        trafficLightManager.southRed();
//        // line 12 "model.ump"
//        trafficLightManager.westRed();
//        // line 13 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case northYellow:
//        // line 18"model.ump"
//        trafficLightManager.northYellow();
//        // line 19 "model.ump"
//        trafficLightManager.southRed();
//        // line 20 "model.ump"
//        trafficLightManager.westRed();
//        // line 21 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case southAndGreenArrow:
//        // line 26"model.ump"
//        trafficLightManager.northRed();
//        // line 27 "model.ump"
//        trafficLightManager.southGreenAndArrow();
//        // line 28 "model.ump"
//        trafficLightManager.westRed();
//        // line 29 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case southYellow:
//        // line 34"model.ump"
//        trafficLightManager.northRed();
//        // line 35 "model.ump"
//        trafficLightManager.southYellow();
//        // line 36 "model.ump"
//        trafficLightManager.westRed();
//        // line 37 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case westAndEastGreen:
//        // line 42"model.ump"
//        trafficLightManager.northRed();
//        // line 43 "model.ump"
//        trafficLightManager.southRed();
//        // line 44 "model.ump"
//        trafficLightManager.westGreen();
//        // line 45 "model.ump"
//        trafficLightManager.eastGreen();
//        break;
//      case westAndEastYellow:
//        // line 49"model.ump"
//        trafficLightManager.northRed();
//        // line 50 "model.ump"
//        trafficLightManager.southRed();
//        // line 51 "model.ump"
//        trafficLightManager.westYellow();
//        // line 52 "model.ump"
//        trafficLightManager.eastYellow();
//        break;
//
//    }
//
//  }
//
//  private void setStatusHighTraffic(StatusHighTraffic aStatusHighTraffic) {
//    statusHighTraffic = aStatusHighTraffic;
//    if (status != Status.HighTraffic && aStatusHighTraffic != StatusHighTraffic.Null) {
//      setStatus(Status.HighTraffic);
//    }
//
//    // entry actions and do activities
//    switch (statusHighTraffic) {
//      case northAndGreenArrow:
//        // line 10 "model.ump"
//        trafficLightManager.northGreenAndArrow();
//        // line 11 "model.ump"
//        trafficLightManager.southRed();
//        // line 12 "model.ump"
//        trafficLightManager.westRed();
//        // line 13 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case northYellow:
//        //line 18"model.ump"
//        trafficLightManager.northYellow();
//        // line 19 "model.ump"
//        trafficLightManager.southRed();
//        // line 20 "model.ump"
//        trafficLightManager.westRed();
//        // line 21 "model.ump"
//        trafficLightManager.eastRed();
//        // break;
//      case southAndGreenArrow:
//        // line 26"model.ump"
//        trafficLightManager.northRed();
//        // line 27 "model.ump"
//        trafficLightManager.southGreenAndArrow();
//        // line 28 "model.ump"
//        trafficLightManager.westRed();
//        // line 29 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case southYellow:
//        // line 34"model.ump"
//        trafficLightManager.northRed();
//        // line 35 "model.ump"
//        trafficLightManager.southYellow();
//        // line 36 "model.ump"
//        trafficLightManager.westRed();
//        // line 37 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case westAndGreenArrow:
//        // line 42"model.ump"
//        trafficLightManager.northRed();
//        // line 43 "model.ump"
//        trafficLightManager.southRed();
//        // line 44 "model.ump"
//        trafficLightManager.westGreenAndArrow();
//        // line 45 "model.ump"
//        trafficLightManager.eastRed();
//        break;
//      case westAndEastGreen:
//        //  line 49"model.ump"
//        trafficLightManager.northRed();
//        // line 50 "model.ump"
//        trafficLightManager.southRed();
//        // line 51 "model.ump"
//        trafficLightManager.westGreen();
//        // line 52 "model.ump"
//        trafficLightManager.eastGreen();
//        break;
//      case westAndEastYellow:
//        // line 56"model.ump"
//        trafficLightManager.northRed();
//        // line 57 "model.ump"
//        trafficLightManager.southRed();
//        //line 58 "model.ump"
//        trafficLightManager.westYellow();
//        // line 59 "model.ump"
//        trafficLightManager.eastYellow();
//        break;
//    }
//  }
//
//  public void delete () {
//  }
//
//  @Override
//  public boolean moderateTraffic () {
//    // TODO Auto-generated method stub
//    return false;
//  }
//
//  @Override
//  public boolean lowTraffic () {
//    // TODO Auto-generated method stub
//    return false;
//  }
//
//  @Override
//  public boolean highTraffic () {
//    // TODO Auto-generated method stub;
//    return false;
//  }
//}

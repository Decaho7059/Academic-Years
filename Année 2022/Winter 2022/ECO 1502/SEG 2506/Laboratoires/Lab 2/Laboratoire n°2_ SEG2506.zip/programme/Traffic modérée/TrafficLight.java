/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/



/**
 * Circulation mod??r??e
 */
// line 3 "model.ump"
// line 60 "model.ump"
public class TrafficLight
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //TrafficLight State Machines
  public enum Status { northAndGreenArrow, northYellow, southAndGreenArrow, southYellow, westAndEastGreen, westAndEastYellow }
  private Status status;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public TrafficLight()
  {
    setStatus(Status.northAndGreenArrow);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public String getStatusFullName()
  {
    String answer = status.toString();
    return answer;
  }

  public Status getStatus()
  {
    return status;
  }

  public boolean timerGreen()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case northAndGreenArrow:
        setStatus(Status.northYellow);
        wasEventProcessed = true;
        break;
      case northYellow:
        setStatus(Status.southAndGreenArrow);
        wasEventProcessed = true;
        break;
      case southYellow:
        setStatus(Status.westAndEastGreen);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        setStatus(Status.northAndGreenArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean timerYellow()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case southAndGreenArrow:
        setStatus(Status.southYellow);
        wasEventProcessed = true;
        break;
      case westAndEastGreen:
        setStatus(Status.westAndEastYellow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private void setStatus(Status aStatus)
  {
    status = aStatus;

    // entry actions and do activities
    switch(status)
    {
      case northAndGreenArrow:
        // line 8 "model.ump"
        trafficLightManager.northGreenAndArrow();
        // line 9 "model.ump"
        trafficLightManager.southRed();
        // line 10 "model.ump"
        trafficLightManager.westRed();
        // line 11 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northYellow:
        // line 16 "model.ump"
        trafficLightManager.northYellow();
        // line 17 "model.ump"
        trafficLightManager.southRed();
        // line 18 "model.ump"
        trafficLightManager.westRed();
        // line 19 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southAndGreenArrow:
        // line 24 "model.ump"
        trafficLightManager.northRed();
        // line 25 "model.ump"
        trafficLightManager.southGreenAndArrow();
        // line 26 "model.ump"
        trafficLightManager.westRed();
        // line 27 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southYellow:
        // line 32 "model.ump"
        trafficLightManager.northRed();
        // line 33 "model.ump"
        trafficLightManager.southYellow();
        // line 34 "model.ump"
        trafficLightManager.westRed();
        // line 35 "model.ump"
        trafficLightManager.eastRed();
        break;
      case westAndEastGreen:
        // line 40 "model.ump"
        trafficLightManager.northRed();
        // line 41 "model.ump"
        trafficLightManager.southRed();
        // line 42 "model.ump"
        trafficLightManager.westGreen();
        // line 43 "model.ump"
        trafficLightManager.eastGreen();
        break;
      case westAndEastYellow:
        // line 47 "model.ump"
        trafficLightManager.northRed();
        // line 48 "model.ump"
        trafficLightManager.southRed();
        // line 49 "model.ump"
        trafficLightManager.westYellow();
        // line 50 "model.ump"
        trafficLightManager.eastYellow();
        break;
    }
  }

  public void delete()
  {}

}
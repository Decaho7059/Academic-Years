/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/



/**
 * Circulation leg??re
 */
// line 3 "model.ump"
// line 49 "model.ump"
public class TrafficLight
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //TrafficLight State Machines
  public enum Status { northAndSouthGreenArrow, northAndSouthGreen, northAndSouthYellow, northAndSouthRed, westAndEastYellow }
  private Status status;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public TrafficLight()
  {
    setStatus(Status.northAndSouthGreenArrow);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public String getStatusFullName()
  {
    String answer = status.toString();
    return answer;
  }

  public Status getStatus()
  {
    return status;
  }

  public boolean timerGreen()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case northAndSouthGreenArrow:
        setStatus(Status.northAndSouthGreen);
        wasEventProcessed = true;
        break;
      case northAndSouthGreen:
        setStatus(Status.northAndSouthYellow);
        wasEventProcessed = true;
        break;
      case northAndSouthRed:
        setStatus(Status.westAndEastYellow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean timerYellow()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case northAndSouthYellow:
        setStatus(Status.northAndSouthRed);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        setStatus(Status.northAndSouthGreenArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private void setStatus(Status aStatus)
  {
    status = aStatus;

    // entry actions and do activities
    switch(status)
    {
      case northAndSouthGreenArrow:
        // line 8 "model.ump"
        trafficLightManager.northGreenArrow();
        // line 9 "model.ump"
        trafficLightManager.southGreenArrow();
        // line 10 "model.ump"
        trafficLightManager.westRed();
        // line 11 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northAndSouthGreen:
        // line 15 "model.ump"
        trafficLightManager.northGreen();
        // line 16 "model.ump"
        trafficLightManager.southGreen();
        // line 17 "model.ump"
        trafficLightManager.westRed();
        // line 18 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northAndSouthYellow:
        // line 22 "model.ump"
        trafficLightManager.northYellow();
        // line 23 "model.ump"
        trafficLightManager.southYellow();
        // line 24 "model.ump"
        trafficLightManager.westRed();
        // line 25 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northAndSouthRed:
        // line 29 "model.ump"
        trafficLightManager.northRed();
        // line 30 "model.ump"
        trafficLightManager.southRed();
        // line 31 "model.ump"
        trafficLightManager.westGreen();
        // line 32 "model.ump"
        trafficLightManager.eastGreen();
        break;
      case westAndEastYellow:
        // line 36 "model.ump"
        trafficLightManager.northRed();
        // line 37 "model.ump"
        trafficLightManager.southRed();
        // line 38 "model.ump"
        trafficLightManager.westYellow();
        // line 39 "model.ump"
        trafficLightManager.eastYellow();
        break;
    }
  }

  public void delete()
  {}

}
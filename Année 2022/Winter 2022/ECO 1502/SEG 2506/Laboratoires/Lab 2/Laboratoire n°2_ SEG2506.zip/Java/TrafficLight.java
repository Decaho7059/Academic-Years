package SEG2106.core;/*PLEASE DO NOT EDIT THIS CODE*/

/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.31.1.5860.78bb27cc6 modeling language!*/



// line 2 "model.ump"
// line 150 "model.ump"
public class TrafficLight implements EventHandler
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //TrafficLight State Machines
  public enum Status { TrafficLight, lowTraffic, moderateTraffic, HighTraffic }
  public enum StatusLowTraffic { Null, northAndSouthGreenArrow, northAndSouthGreen, northAndSouthYellow, northAndSouthRed, westAndEastYellow }
  public enum StatusModerateTraffic { Null, northGreenArrow, northYellow, southAndGreenArrow, southYellow, westAndEastGreen, westAndEastYellowM }
  public enum StatusHighTraffic { Null, northGreenArrowH, northYellowH, southGreenArrowH, southYellowH, westGreenArrow, westEastGreen, westAndEastYellowH }
  private Status status;
  private StatusLowTraffic statusLowTraffic;
  private StatusModerateTraffic statusModerateTraffic;
  private StatusHighTraffic statusHighTraffic;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  private final TrafficLightManager trafficLightManager;
  public TrafficLight(TrafficLightManager trafficLightManager)
  {
	  this.trafficLightManager = trafficLightManager;
	  
	  setStatusLowTrafficMode(StatusLowTrafficMode.Null);
	  setStatusModerateTrafficMode(StatusModerateTrafficMode.Null);
	  setStatusHighTrafficMode(StatusHighTrafficMode.Null);
	  setStatus(Status.initialTrafficMode);
	  
	  trafficLightManager.addEventHandler(this);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public String getStatusFullName()
  {
    String answer = status.toString();
    if (statusLowTraffic != StatusLowTraffic.Null) { answer += "." + statusLowTraffic.toString(); }
    if (statusModerateTraffic != StatusModerateTraffic.Null) { answer += "." + statusModerateTraffic.toString(); }
    if (statusHighTraffic != StatusHighTraffic.Null) { answer += "." + statusHighTraffic.toString(); }
    return answer;
  }

  public Status getStatus()
  {
    return status;
  }

  public StatusLowTraffic getStatusLowTraffic()
  {
    return statusLowTraffic;
  }

  public StatusModerateTraffic getStatusModerateTraffic()
  {
    return statusModerateTraffic;
  }

  public StatusHighTraffic getStatusHighTraffic()
  {
    return statusHighTraffic;
  }

  public boolean lowTraffic()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case TrafficLight:
        setStatus(Status.lowTraffic);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean moderateTraffic()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case TrafficLight:
        setStatus(Status.moderateTraffic);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean highTraffic()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case TrafficLight:
        setStatus(Status.HighTraffic);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean timerGreen()
  {
    boolean wasEventProcessed = false;
    
    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
    switch (aStatusLowTraffic)
    {
      case northAndSouthGreenArrow:
        exitStatusLowTraffic();
        setStatusLowTraffic(StatusLowTraffic.northAndSouthGreen);
        wasEventProcessed = true;
        break;
      case northAndSouthGreen:
        exitStatusLowTraffic();
        setStatusLowTraffic(StatusLowTraffic.northAndSouthYellow);
        wasEventProcessed = true;
        break;
      case northAndSouthRed:
        exitStatusLowTraffic();
        setStatusLowTraffic(StatusLowTraffic.westAndEastYellow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aStatusModerateTraffic)
    {
      case northGreenArrow:
        exitStatusModerateTraffic();
        setStatusModerateTraffic(StatusModerateTraffic.northYellow);
        wasEventProcessed = true;
        break;
      case southAndGreenArrow:
        exitStatusModerateTraffic();
        setStatusModerateTraffic(StatusModerateTraffic.southYellow);
        wasEventProcessed = true;
        break;
      case westAndEastGreen:
        exitStatusModerateTraffic();
        setStatusModerateTraffic(StatusModerateTraffic.westAndEastYellowM);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aStatusHighTraffic)
    {
      case northGreenArrowH:
        exitStatusHighTraffic();
        setStatusHighTraffic(StatusHighTraffic.northYellowH);
        wasEventProcessed = true;
        break;
      case southGreenArrowH:
        exitStatusHighTraffic();
        setStatusHighTraffic(StatusHighTraffic.southYellowH);
        wasEventProcessed = true;
        break;
      case westGreenArrow:
        exitStatusHighTraffic();
        setStatusHighTraffic(StatusHighTraffic.westEastGreen);
        wasEventProcessed = true;
        break;
      case westEastGreen:
        exitStatusHighTraffic();
        setStatusHighTraffic(StatusHighTraffic.westAndEastYellowH);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean timerYellow()
  {
    boolean wasEventProcessed = false;
    
    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
    switch (aStatusLowTraffic)
    {
      case northAndSouthYellow:
        exitStatusLowTraffic();
        setStatusLowTraffic(StatusLowTraffic.northAndSouthRed);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        exitStatusLowTraffic();
        setStatusLowTraffic(StatusLowTraffic.northAndSouthGreenArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aStatusModerateTraffic)
    {
      case northYellow:
        exitStatusModerateTraffic();
        setStatusModerateTraffic(StatusModerateTraffic.southAndGreenArrow);
        wasEventProcessed = true;
        break;
      case southYellow:
        exitStatusModerateTraffic();
        setStatusModerateTraffic(StatusModerateTraffic.westAndEastGreen);
        wasEventProcessed = true;
        break;
      case westAndEastYellowM:
        exitStatusModerateTraffic();
        setStatusModerateTraffic(StatusModerateTraffic.northGreenArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aStatusHighTraffic)
    {
      case northYellowH:
        exitStatusHighTraffic();
        setStatusHighTraffic(StatusHighTraffic.southGreenArrowH);
        wasEventProcessed = true;
        break;
      case southYellowH:
        exitStatusHighTraffic();
        setStatusHighTraffic(StatusHighTraffic.westGreenArrow);
        wasEventProcessed = true;
        break;
      case westAndEastYellowH:
        exitStatusHighTraffic();
        setStatusHighTraffic(StatusHighTraffic.northGreenArrowH);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private void exitStatus()
  {
    switch(status)
    {
      case lowTraffic:
        exitStatusLowTraffic();
        break;
      case moderateTraffic:
        exitStatusModerateTraffic();
        break;
      case HighTraffic:
        exitStatusHighTraffic();
        break;
    }
  }

  private void setStatus(Status aStatus)
  {
    status = aStatus;

    // entry actions and do activities
    switch(status)
    {
      case lowTraffic:
        if (statusLowTraffic == StatusLowTraffic.Null) { setStatusLowTraffic(StatusLowTraffic.northAndSouthGreenArrow); }
        break;
      case moderateTraffic:
        if (statusModerateTraffic == StatusModerateTraffic.Null) { setStatusModerateTraffic(StatusModerateTraffic.northGreenArrow); }
        break;
      case HighTraffic:
        if (statusHighTraffic == StatusHighTraffic.Null) { setStatusHighTraffic(StatusHighTraffic.northGreenArrowH); }
        break;
    }
  }

  private void exitStatusLowTraffic()
  {
    switch(statusLowTraffic)
    {
      case northAndSouthGreenArrow:
        setStatusLowTraffic(StatusLowTraffic.Null);
        break;
      case northAndSouthGreen:
        setStatusLowTraffic(StatusLowTraffic.Null);
        break;
      case northAndSouthYellow:
        setStatusLowTraffic(StatusLowTraffic.Null);
        break;
      case northAndSouthRed:
        setStatusLowTraffic(StatusLowTraffic.Null);
        break;
      case westAndEastYellow:
        setStatusLowTraffic(StatusLowTraffic.Null);
        break;
    }
  }

  private void setStatusLowTraffic(StatusLowTraffic aStatusLowTraffic)
  {
    statusLowTraffic = aStatusLowTraffic;
    if (status != Status.lowTraffic && aStatusLowTraffic != StatusLowTraffic.Null) { setStatus(Status.lowTraffic); }

    // entry actions and do activities
    switch(statusLowTraffic)
    {
      case northAndSouthGreenArrow:
        // line 12 "model.ump"
        trafficLightManager.northArrow();
        // line 13 "model.ump"
        trafficLightManager.southArrow();
        // line 14 "model.ump"
        trafficLightManager.westRed();
        // line 15 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northAndSouthGreen:
        // line 19 "model.ump"
        trafficLightManager.northGreen();
        // line 20 "model.ump"
        trafficLightManager.southGreen();
        // line 21 "model.ump"
        trafficLightManager.westRed();
        // line 22 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northAndSouthYellow:
        // line 26 "model.ump"
        trafficLightManager.northYellow();
        // line 27 "model.ump"
        trafficLightManager.southYellow();
        // line 28 "model.ump"
        trafficLightManager.westRed();
        // line 29 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northAndSouthRed:
        // line 33 "model.ump"
        trafficLightManager.northRed();
        // line 34 "model.ump"
        trafficLightManager.southRed();
        // line 35 "model.ump"
        trafficLightManager.westGreen();
        // line 36 "model.ump"
        trafficLightManager.eastGreen();
        break;
      case westAndEastYellow:
        // line 40 "model.ump"
        trafficLightManager.northRed();
        // line 41 "model.ump"
        trafficLightManager.southRed();
        // line 42 "model.ump"
        trafficLightManager.westYellow();
        // line 43 "model.ump"
        trafficLightManager.eastYellow();
        break;
    }
  }

  private void exitStatusModerateTraffic()
  {
    switch(statusModerateTraffic)
    {
      case northGreenArrow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        break;
      case northYellow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        break;
      case southAndGreenArrow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        break;
      case southYellow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        break;
      case westAndEastGreen:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        break;
      case westAndEastYellowM:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        break;
    }
  }

  private void setStatusModerateTraffic(StatusModerateTraffic aStatusModerateTraffic)
  {
    statusModerateTraffic = aStatusModerateTraffic;
    if (status != Status.moderateTraffic && aStatusModerateTraffic != StatusModerateTraffic.Null) { setStatus(Status.moderateTraffic); }

    // entry actions and do activities
    switch(statusModerateTraffic)
    {
      case northGreenArrow:
        // line 51 "model.ump"
        trafficLightManager.northGreenAndArrow();
        // line 52 "model.ump"
        trafficLightManager.southRed();
        // line 53 "model.ump"
        trafficLightManager.westRed();
        // line 54 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northYellow:
        // line 58 "model.ump"
        trafficLightManager.northYellow();
        // line 59 "model.ump"
        trafficLightManager.southRed();
        // line 60 "model.ump"
        trafficLightManager.westRed();
        // line 61 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southAndGreenArrow:
        // line 65 "model.ump"
        trafficLightManager.northRed();
        // line 66 "model.ump"
        trafficLightManager.southGreenAndArrow();
        // line 67 "model.ump"
        trafficLightManager.westRed();
        // line 68 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southYellow:
        // line 72 "model.ump"
        trafficLightManager.northRed();
        // line 73 "model.ump"
        trafficLightManager.southYellow();
        // line 74 "model.ump"
        trafficLightManager.westRed();
        // line 75 "model.ump"
        trafficLightManager.eastRed();
        break;
      case westAndEastGreen:
        // line 79 "model.ump"
        trafficLightManager.northRed();
        // line 80 "model.ump"
        trafficLightManager.southRed();
        // line 81 "model.ump"
        trafficLightManager.westGreen();
        // line 82 "model.ump"
        trafficLightManager.eastGreen();
        break;
      case westAndEastYellowM:
        // line 86 "model.ump"
        trafficLightManager.northRed();
        // line 87 "model.ump"
        trafficLightManager.southRed();
        // line 88 "model.ump"
        trafficLightManager.westYellow();
        // line 89 "model.ump"
        trafficLightManager.eastYellow();
        break;
    }
  }

  private void exitStatusHighTraffic()
  {
    switch(statusHighTraffic)
    {
      case northGreenArrowH:
        setStatusHighTraffic(StatusHighTraffic.Null);
        break;
      case northYellowH:
        setStatusHighTraffic(StatusHighTraffic.Null);
        break;
      case southGreenArrowH:
        setStatusHighTraffic(StatusHighTraffic.Null);
        break;
      case southYellowH:
        setStatusHighTraffic(StatusHighTraffic.Null);
        break;
      case westGreenArrow:
        setStatusHighTraffic(StatusHighTraffic.Null);
        break;
      case westEastGreen:
        setStatusHighTraffic(StatusHighTraffic.Null);
        break;
      case westAndEastYellowH:
        setStatusHighTraffic(StatusHighTraffic.Null);
        break;
    }
  }

  private void setStatusHighTraffic(StatusHighTraffic aStatusHighTraffic)
  {
    statusHighTraffic = aStatusHighTraffic;
    if (status != Status.HighTraffic && aStatusHighTraffic != StatusHighTraffic.Null) { setStatus(Status.HighTraffic); }

    // entry actions and do activities
    switch(statusHighTraffic)
    {
      case northGreenArrowH:
        // line 95 "model.ump"
        trafficLightManager.northGreenAndArrow();
        // line 96 "model.ump"
        trafficLightManager.southRed();
        // line 97 "model.ump"
        trafficLightManager.westRed();
        // line 98 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northYellowH:
        // line 102 "model.ump"
        trafficLightManager.northYellow();
        // line 103 "model.ump"
        trafficLightManager.southRed();
        // line 104 "model.ump"
        trafficLightManager.westRed();
        // line 105 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southGreenArrowH:
        // line 109 "model.ump"
        trafficLightManager.northRed();
        // line 110 "model.ump"
        trafficLightManager.southGreenAndArrow();
        // line 111 "model.ump"
        trafficLightManager.westRed();
        // line 112 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southYellowH:
        // line 116 "model.ump"
        trafficLightManager.northRed();
        // line 117 "model.ump"
        trafficLightManager.southYellow();
        // line 118 "model.ump"
        trafficLightManager.westRed();
        // line 119 "model.ump"
        trafficLightManager.eastRed();
        break;
      case westGreenArrow:
        // line 123 "model.ump"
        trafficLightManager.northRed();
        // line 124 "model.ump"
        trafficLightManager.southRed();
        // line 125 "model.ump"
        trafficLightManager.westGreenAndArrow();
        // line 126 "model.ump"
        trafficLightManager.eastRed();
        break;
      case westEastGreen:
        // line 130 "model.ump"
        trafficLightManager.northRed();
        // line 131 "model.ump"
        trafficLightManager.southRed();
        // line 132 "model.ump"
        trafficLightManager.westGreen();
        // line 133 "model.ump"
        trafficLightManager.eastGreen();
        break;
      case westAndEastYellowH:
        // line 137 "model.ump"
        trafficLightManager.northRed();
        // line 138 "model.ump"
        trafficLightManager.southRed();
        // line 139 "model.ump"
        trafficLightManager.westYellow();
        // line 140 "model.ump"
        trafficLightManager.eastYellow();
        break;
    }
  }

  public void delete()
  {}

}
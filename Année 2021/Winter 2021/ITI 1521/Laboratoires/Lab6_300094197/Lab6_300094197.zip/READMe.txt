Nom étudiant: Gbegbe Decaho Jacques
Numéro d'étudiant: 300094197
Code du cours: ITI1521
Section Lab: A01

Labo 6

